﻿using System.Windows.Forms;

namespace Digger
{
    public class Bomb : ICreature
    {
        public string GetImageFileName()
        {
            return "Bomb.png";
        }

        public int GetDrawingPriority()
        {
            return 5;
        }

        public CreatureCommand Act(int x, int y)
        {
            return new CreatureCommand();
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            return conflictedObject is Monster || conflictedObject is Player;
        }
    }
    public class Monster : ICreature
    {
        public string GetImageFileName() => "Monster.png";

        public int GetDrawingPriority() => 1;

        public CreatureCommand Act(int x, int y)
        {
            var dx = 0;
            var dy = 0;

            if (IsPlayerReachable())
            {
                var arr = MoveMonster(x, y, dx, dy);
                dx = arr[0];
                dy = arr[1];
            }

            if (!(x + dx < Game.MapWidth && x + dx >= 0 && y + dy < Game.MapHeight && y + dy >= 0))
            {
                dx = 0;
                dy = 0;
                return new CreatureCommand {DeltaX = dx, DeltaY = dy};
            }

            if (Game.Map[x + dx, y + dy] == null || (!(Game.Map[x + dx, y + dy] is Sack) &&
                                                     !(Game.Map[x + dx, y + dy] is Terrain) &&
                                                     !(Game.Map[x + dx, y + dy] is Monster)))
                return new CreatureCommand {DeltaX = dx, DeltaY = dy};
            dx = 0;
            dy = 0;
            return new CreatureCommand {DeltaX = dx, DeltaY = dy};
        }

        private static int[] MoveMonster(int x, int y, int dx, int dy)
        {
            if (Player.Y == y)
            {
                if (Player.X > x) dx = 1;
                else if (Player.X < x) dx = -1;
            }

            else if (Player.X == x)
            {
                if (Player.Y > y) dy = 1;
                else if (Player.Y < y) dy = -1;
            }

            else if (Player.X != x && Player.Y != y)
            {
                if (Player.X > x) dx = 1;
                else if (Player.X < x) dx = -1;
                else if (Player.Y > y) dy = 1;
                else if (Player.Y < y) dy = -1;
            }

            return new[] {dx, dy};
        }

        private static bool IsPlayerReachable()
        {
            for (var i = 0; i < Game.MapHeight; i++)
            for (var j = 0; j < Game.MapWidth; j++)
                if (Game.Map[j, i] != null && Game.Map[j, i] is Player)
                {
                    Player.X = j;
                    Player.Y = i;
                    return true;
                }

            return false;
        }

        public bool DeadInConflict(ICreature conflictedObject) =>
            conflictedObject is Monster || conflictedObject is Sack sack && sack.K > 1 || conflictedObject is Bomb;
    }
    public class Sack : ICreature
    {
        public int K;

        public string GetImageFileName()
        {
            return "Sack.png";
        }

        public int GetDrawingPriority()
        {
            return 5;
        }

        public CreatureCommand Act(int x, int y)
        {
            if (Game.MapHeight - 1 > y)
            {
                var cellBelow = Game.Map[x, y + 1];
                if (cellBelow == null || K > 0 &&
                    (cellBelow is Player || cellBelow is Monster))
                {
                    K++;
                    return new CreatureCommand {DeltaX = 0, DeltaY = 1};
                }
            }

            if (K > 1)
            {
                K = 0;
                return new CreatureCommand {DeltaX = 0, DeltaY = 0, TransformTo = new Gold()};
            }

            K = 0;
            return new CreatureCommand {DeltaX = 0, DeltaY = 0};
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            return false;
        }
    }
    public class Player : ICreature
    {
        public static int X;
        public static int Y;

        public string GetImageFileName()
        {
            return "Digger.png";
        }

        public int GetDrawingPriority()
        {
            return 1;
        }

        public CreatureCommand Act(int x, int y)
        {
            switch (Game.KeyPressed)
            {
                case Keys.Right when x + 1 < Game.MapWidth && x + 1 >= 0 && !(Game.Map[x + 1, y] is Sack):
                    return new CreatureCommand {DeltaX = 1, DeltaY = 0};
                case Keys.Left when x - 1 < Game.MapWidth && x - 1 >= 0 && !(Game.Map[x - 1, y] is Sack):
                    return new CreatureCommand {DeltaX = -1, DeltaY = 0};
                case Keys.Up when y - 1 < Game.MapHeight && y - 1 >= 0 && !(Game.Map[x, y - 1] is Sack):
                    return new CreatureCommand {DeltaX = 0, DeltaY = -1};
                case Keys.Down when y + 1 < Game.MapHeight && y + 1 >= 0 && !(Game.Map[x, y + 1] is Sack):
                    return new CreatureCommand {DeltaX = 0, DeltaY = 1};
                case Keys.M when y + 1 < Game.MapHeight && y + 1 >= 0 && (Game.Map[x, y + 1] is null):
                    Game.Map[x, y + 1] = new Bomb();
                    break;
                default:
                    return new CreatureCommand();
            }
            return new CreatureCommand();
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            if (conflictedObject is Gold) Game.Scores += 10;
            return conflictedObject is Monster || conflictedObject is Sack sack && sack.K > 1 || conflictedObject is Bomb;
        }
    }
    public class Terrain : ICreature
    {
        public string GetImageFileName()
        {
            return "Terrain.png";
        }

        public int GetDrawingPriority()
        {
            return 2;
        }

        public CreatureCommand Act(int x, int y)
        {
            return new CreatureCommand {DeltaX = 0, DeltaY = 0};
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            return true;
        }
    }
    public class Gold : ICreature
    {
        public string GetImageFileName()
        {
            return "Gold.png";
        }

        public int GetDrawingPriority()
        {
            return 3;
        }

        public CreatureCommand Act(int x, int y)
        {
            return new CreatureCommand();
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            return conflictedObject is Player || conflictedObject is Monster;
        }
    }
}