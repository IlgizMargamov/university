﻿using System;
using System.Drawing;

namespace Names
{
    internal static class CreativityTask
    {
        public static HeatmapData GetBirthsPerDateHeatmap(NameData[] names, string name)
        {
            const int firstDay = 2;
            const int lastDay = 31;
            var daysInMonth = new string[lastDay - firstDay + 1];
            EstablishArrayOfDates(firstDay, lastDay, daysInMonth);

            const int firstMonth = 1;
            const int lastMonth = 12;
            var monthInYear = new string[lastMonth - firstMonth + 1];
            EstablishArrayOfDates(firstMonth, lastMonth, monthInYear);

            var births = new double[daysInMonth.Length, monthInYear.Length];
            foreach (var personName in names)
                if (personName.BirthDate.Day > 1 && personName.Name.Equals(name))
                    births[(personName.BirthDate.Day - firstDay), (personName.BirthDate.Month - firstMonth)]++;

            var birthsDiff = new double[daysInMonth.Length, monthInYear.Length];

            foreach (var personName in names)
            {
                if (personName.BirthDate.Day >= 2 && personName.BirthDate.Month >= 1 && personName.Name.Equals(name))
                    birthsDiff[(personName.BirthDate.Day - firstDay), (personName.BirthDate.Month - firstMonth)] =
                        births[(personName.BirthDate.Day - firstDay), (personName.BirthDate.Month - firstMonth)];
                if (personName.BirthDate.Day > 2 && personName.Name.Equals(name) && personName.BirthDate.Month > 1)
                    birthsDiff[(personName.BirthDate.Day - firstDay), (personName.BirthDate.Month - firstMonth)] =
                        births[(personName.BirthDate.Day - firstDay), (personName.BirthDate.Month - firstMonth)] -
                        births[(personName.BirthDate.Day - firstDay), (personName.BirthDate.Month - firstMonth - 1)];
            }

            return new HeatmapData(
                $"Карта интенсивности рождаемости {name}", birthsDiff, daysInMonth, monthInYear);
        }

        private static void EstablishArrayOfDates(int firstDate, int lastDate, string[] period)
        {
            for (var date = 0; date < period.Length; date++)
                period[date] = (date + firstDate).ToString();
        }
    }
}