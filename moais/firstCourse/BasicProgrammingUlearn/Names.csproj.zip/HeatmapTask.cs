﻿using System;
using System.Linq;

namespace Names
{
    internal static class HeatmapTask
    {
        public static HeatmapData GetBirthsPerDateHeatmap(NameData[] names)
        {
            const int firstDay = 2;
            const int lastDay = 31;
            var daysInMonth = new string[lastDay - firstDay + 1];
            EstablishArrayOfDates(firstDay, lastDay, daysInMonth);

            const int firstMonth = 1;
            const int lastMonth = 12;
            var monthInYear = new string[lastMonth - firstMonth + 1];
            EstablishArrayOfDates(firstMonth, lastMonth, monthInYear);

            var births = new double[daysInMonth.Length, monthInYear.Length];
            foreach (var name in names)
                if (name.BirthDate.Day > 1)
                    births[(name.BirthDate.Day - firstDay), (name.BirthDate.Month - firstMonth)]++;

            return new HeatmapData(
                "Карта интенсивности рождаемости", births, daysInMonth, monthInYear);
        }

        private static void EstablishArrayOfDates(int firstDate, int lastDate, string[] period)
        {
            for (var date = 0; date < period.Length; date++)
                period[date] = (date + firstDate).ToString();
        }
    }
}