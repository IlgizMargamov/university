﻿using System;
using System.Linq;

namespace Names
{
    internal static class HistogramTask
    {
        public static HistogramData GetBirthsPerDayHistogram(NameData[] names, string name)
        {
            const int firstDay = 1;
            var lastDay = int.MinValue;
            foreach (var personName in names)
                lastDay = Math.Max(lastDay, personName.BirthDate.Day);

            var daysInMonth = new string[lastDay - firstDay + 1];
            for (var day = 0; day < daysInMonth.Length; day++)
                daysInMonth[day] = (day + firstDay).ToString();

            var birthCount = new double[lastDay - firstDay + 1];
            foreach (var day in names)
                if (day.Name == name && day.BirthDate.Day > 1)
                    birthCount[day.BirthDate.Day - firstDay]++;

            return new HistogramData($"Рождаемость людей с именем '{name}'",
                daysInMonth, birthCount);
        }
    }
}