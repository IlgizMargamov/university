﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Dungeon
{
    public class DungeonTask
    {
        public static MoveDirection[] FindShortestPath(Map map)
        {
            var chests = map.Chests;
            var exitPath = BfsTask.FindPaths(map, map.InitialPosition, new[] {map.Exit}).FirstOrDefault();
            if (exitPath == null) return new MoveDirection[0];
            if (chests.Any(chest => exitPath.Contains(chest)))
                return exitPath.ToListAndParseToArray();
            var chestPaths = BfsTask.FindPaths(map, map.InitialPosition, chests);
            var output = chestPaths
                .Select(chest => Tuple.Create(chest, BfsTask.FindPaths(map, chest.Value, new[] {map.Exit})
                    .FirstOrDefault()))
                .TryGetQuickestWay();
            return output == null
                ? exitPath.ToListAndParseToArray()
                : output.Item1.ToListAndParseToArray()
                    .Concat(output.Item2.ToListAndParseToArray())
                    .ToArray();
        }
    }

    internal static class Extensions
    {
        public static MoveDirection[] ToListAndParseToArray(this SinglyLinkedList<Point> exitPath)
        {
            return exitPath
                .ToList()
                .ParseListToArray();
        }

        public static Tuple<SinglyLinkedList<Point>, SinglyLinkedList<Point>> TryGetQuickestWay(
            this IEnumerable<Tuple<SinglyLinkedList<Point>, SinglyLinkedList<Point>>> chestPaths)
        {
            var path = chestPaths as Tuple<SinglyLinkedList<Point>, SinglyLinkedList<Point>>[] ?? chestPaths.ToArray();
            if (!path.Any() || path.First().Item2 == null) return null;
            var min = int.MaxValue;
            var toReturn = path.First();
            foreach (var tuple in path)
            {
                if (tuple.Item1.Length + tuple.Item2.Length >= min) continue;
                min = tuple.Item1.Length + tuple.Item2.Length;
                toReturn = tuple;
            }

            return toReturn;
        }

        private static MoveDirection[] ParseListToArray(this List<Point> exitPath)
        {
            if (!exitPath.Any()) return new MoveDirection[0];
            var output = new List<MoveDirection>();
            for (var i = exitPath.Count - 1; i > 0; i--)
                output.Add(Walker.ConvertOffsetToDirection(new Size(exitPath[i - 1].X - exitPath[i].X,
                    exitPath[i - 1].Y - exitPath[i].Y)));
            return output.ToArray();
        }
    }
}