using System.Collections.Generic;
using System.Drawing;

namespace Dungeon
{
    public class BfsTask
    {
        public static IEnumerable<SinglyLinkedList<Point>> FindPaths(Map map, Point start, Point[] chests)
        {
            var startingPoint = new Queue<Point>();
            var visitedPoints = new HashSet<Point>();
            var paths = new Dictionary<Point, SinglyLinkedList<Point>>();
            RememberPoint(start, new Point(int.MaxValue, int.MinValue), startingPoint, visitedPoints, paths);
            while (startingPoint.Count > 0)
            {
                var point = startingPoint.Dequeue();
                if (point.X < 0 || point.X >= map.Dungeon.GetLength(0) || point.Y < 0 ||
                    point.Y >= map.Dungeon.GetLength(1) || map.Dungeon[point.X, point.Y] != MapCell.Empty) continue;
                for (var dy = -1; dy <= 1; dy++)
                for (var dx = -1; dx <= 1; dx++)
                {
                    if (dx != 0 && dy != 0) continue;
                    var next = new Point(point.X + dx, point.Y + dy);
                    if (visitedPoints.Contains(next)) continue;
                    RememberPoint(next, point, startingPoint, visitedPoints, paths);
                }
            }

            foreach (var chest in chests)
                if (paths.ContainsKey(chest))
                    yield return paths[chest];
        }

        private static void RememberPoint(Point start, Point point, Queue<Point> startingPoint,
            HashSet<Point> visitedPoints, Dictionary<Point, SinglyLinkedList<Point>> paths)
        {
            visitedPoints.Add(start);
            startingPoint.Enqueue(start);
            paths.Add(start,
                point == new Point(int.MaxValue, int.MinValue)
                    ? new SinglyLinkedList<Point>(start)
                    : new SinglyLinkedList<Point>(start, paths[point]));
        }
    }
}