﻿namespace Dungeon
{
	public enum MapCell
	{
		Wall,
		Empty
	}
}
