using System.Collections.Generic;

namespace yield
{
    public static class MovingMaxTask
    {
        public static IEnumerable<DataPoint> MovingMax(this IEnumerable<DataPoint> data, int windowWidth)
        {
            var maximizer = new Maximizer(windowWidth);
            foreach (var dataPoint in data)
                yield return maximizer.Maximize(dataPoint);
        }
    }
}