﻿using System.Collections.Generic;
using System.Linq;

namespace yield
{
    /// <summary>
    /// Works in O(1)
    /// </summary>
    public class Maximizer
    {
        private readonly LinkedList<double> dataPoints;
        private readonly Queue<double> totalDataPoints;
        private readonly double windowWidth;

        public Maximizer(double windowWidth)
        {
            this.windowWidth = windowWidth;
            totalDataPoints = new Queue<double>();
            dataPoints = new LinkedList<double>();
        }

        public DataPoint Maximize(DataPoint dataPoint)
        {
            totalDataPoints.Enqueue(dataPoint.X);
            if (totalDataPoints.Count > windowWidth && dataPoints.First.Value <= totalDataPoints.Dequeue())
                dataPoints.RemoveFirstTwice();

            while (dataPoints.Count != 0 && dataPoints.Last.Value < dataPoint.OriginalY)
                dataPoints.RemoveLastTwice();

            dataPoints.AddLast(dataPoint.X);
            dataPoints.AddLast(dataPoint.OriginalY);
            return dataPoints.First.Next != null
                ? dataPoint.WithMaxY(dataPoints.First.Next.Value)
                : new DataPoint(dataPoint);
        }
    }

    public static class LinkedListExtensions
    {
        public static void RemoveFirstTwice<T>(this LinkedList<T> linkedList)
        {
            linkedList.RemoveFirst();
            linkedList.RemoveFirst();
        }

        public static void RemoveLastTwice<T>(this LinkedList<T> linkedList)
        {
            linkedList.RemoveLast();
            linkedList.RemoveLast();
        }
    }

    /// <summary>
    /// Works in O(bufferLength)
    /// </summary>
    public class Maximizer1
    {
        private readonly int bufferLength;
        private Queue<double> queue;

        public Maximizer1(int bufferLength)
        {
            this.bufferLength = bufferLength;
            queue = new Queue<double>();
        }

        public double Measure(DataPoint dataPoint)
        {
            var value = dataPoint.OriginalY;
            queue.Enqueue(value);
            if (queue.Count > bufferLength) queue.Dequeue();
            return queue.Max();
        }
    }
}