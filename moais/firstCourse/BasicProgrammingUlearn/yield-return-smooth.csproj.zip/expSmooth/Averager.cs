﻿using System.Collections.Generic;

namespace yield
{
    public class Averager
    {
        private readonly Queue<double> queue;
        private readonly int bufferLength;
        private double sum;

        public Averager(int bufferLength)
        {
            this.bufferLength = bufferLength;
            queue = new Queue<double>();
        }

        public double Measure(DataPoint dataPoint)
        {
            var value = dataPoint.OriginalY;
            queue.Enqueue(value);
            sum += value;
            if (queue.Count > bufferLength)
            {
                sum -= queue.Dequeue();
            }

            return sum / queue.Count;
        }
    }
}