using System.Collections.Generic;

namespace yield
{
    public static class MovingAverageTask
    {
        public static IEnumerable<DataPoint> MovingAverage(this IEnumerable<DataPoint> data, int windowWidth)
        {
            var averager = new Averager(windowWidth);
            foreach (var dataPoint in data)
            {
                var previousPoint = averager.Measure(dataPoint);
                yield return dataPoint.WithAvgSmoothedY(previousPoint);
            }
        }
    }
}