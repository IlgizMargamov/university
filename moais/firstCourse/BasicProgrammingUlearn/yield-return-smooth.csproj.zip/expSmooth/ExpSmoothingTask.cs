using System.Collections.Generic;

namespace yield
{
    public static class ExpSmoothingTask
    {
        public static IEnumerable<DataPoint> SmoothExponentialy(this IEnumerable<DataPoint> data, double alpha)
        {
            var isFirst = true;
            var previousPoint = 0.0;
            foreach (var dataPoint in data)
            {
                if (isFirst)
                {
                    isFirst = false;
                    previousPoint = dataPoint.OriginalY;
                }
                else
                    previousPoint = dataPoint.OriginalY * alpha + (1 - alpha) * previousPoint;

                yield return dataPoint.WithExpSmoothedY(previousPoint);
            }
        }
    }
}