using NUnitLite;

namespace GaussAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            new AutoRun().Execute(args);
        }
    }
}
