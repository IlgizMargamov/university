﻿namespace StructBenchmarking
{
    public interface Result1
    {
        void Run();
    }
}