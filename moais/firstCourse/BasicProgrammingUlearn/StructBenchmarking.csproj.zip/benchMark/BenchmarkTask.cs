using System;
using System.Diagnostics;
using System.Text;
using NUnit.Framework;

namespace StructBenchmarking
{
    public class Benchmark : IBenchmark
    {
        public double MeasureDurationInMs(ITask task, int repetitionCount)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            task.Run();
            var timer = new Stopwatch();
            timer.Start();
            for (var i = 0; i < repetitionCount; i++)
                task.Run();
            timer.Stop();
            return (double) timer.ElapsedMilliseconds / repetitionCount;
        }
    }

    public class TaskBuilder : ITask
    {
        public void Run()
        {
            var builder = new StringBuilder();
            for (var i = 0; i < 10000; i++)
                builder = builder.Append("a");
            var builder1 = builder.ToString();
        }
    }

    public class TaskStringer : ITask
    {
        public void Run()
        {
            var str = new string('a', 10000);
        }
    }

    [TestFixture]
    public class RealBenchmarkUsageSample
    {
        [Test]
        public void StringConstructorFasterThanStringBuilder()
        {
            Assert.Less(new Benchmark().MeasureDurationInMs(new TaskStringer(), 10000),
                new Benchmark().MeasureDurationInMs(new TaskBuilder(), 10000));
        }
    }
}