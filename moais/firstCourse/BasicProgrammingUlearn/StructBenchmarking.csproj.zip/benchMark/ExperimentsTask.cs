using System;
using System.Collections.Generic;
using System.Linq;

namespace StructBenchmarking
{
    public static class Experiments
    {
        public static ChartData BuildChartDataForArrayCreation(Benchmark benchmark, int repetitionsCount)
        {
            return Result.BuildChartData(benchmark, repetitionsCount, size => new ClassArrayCreationTask(size),
                size => new StructArrayCreationTask(size));
        }

        public static ChartData BuildChartDataForMethodCall(Benchmark benchmark, int repetitionsCount)
        {
            return Result.BuildChartData(benchmark, repetitionsCount, size => new MethodCallWithClassArgumentTask(size),
                size => new MethodCallWithStructArgumentTask(size));
        }
    }

    public static class Result
    {
        private static readonly IReadOnlyCollection<int> Constant = Constants.FieldCounts;

        public static ChartData BuildChartData(Benchmark benchmark, int repetitionsCount, Func<int, ITask> classTask,
            Func<int, ITask> structTask)
        {
            GC.Collect();
            var classesTimes = new List<ExperimentResult>();
            var structuresTimes = new List<ExperimentResult>();
            for (var i = 0; i < Constant.Count; i++)
            {
                var fieldsCountI = Constant.ElementAt(i);
                RunTests(classTask(fieldsCountI), repetitionsCount, fieldsCountI, classesTimes, benchmark);
                RunTests(structTask(fieldsCountI), repetitionsCount, fieldsCountI, structuresTimes, benchmark);
            }

            return new ChartData
            {
                Title = "Call method with argument",
                ClassPoints = classesTimes,
                StructPoints = structuresTimes,
            };
        }

        private static void RunTests(ITask task, int repetitionsCount, int fieldsCountI, List<ExperimentResult> times,
            IBenchmark benchmark)
        {
            times.Add(new ExperimentResult(fieldsCountI,
                RunBenchmarkOnTask(benchmark, task, repetitionsCount)));
        }

        private static double RunBenchmarkOnTask(IBenchmark benchmark, ITask task, int repCount)
        {
            return benchmark.MeasureDurationInMs(task, repCount);
        }
    }
}