﻿using System.Collections.Generic;

namespace Clones
{
	public class CloneVersionSystem : ICloneVersionSystem
	{
		private readonly List<Clone> clonesList;

		public CloneVersionSystem()
		{
			clonesList = new List<Clone> {new Clone()};
		}
		
		public string Execute(string query)
		{
			var request = query.Split();
			var cloneNumber = int.Parse(request[1])-1;
			switch (request[0])
			{
				case "learn":
					var programNumber = int.Parse(request[2]);
					clonesList[cloneNumber].Learn(programNumber);
					return null;
				case "rollback":
					clonesList[cloneNumber].RollBack();
					return null;
				case "relearn":
					clonesList[cloneNumber].Relearn();
					return null;
				case "clone":
					clonesList.Add(new Clone(clonesList[cloneNumber]));
					return null;
				case "check":
					return clonesList[cloneNumber].Check();
			}
			return null;
		}
	}
}
