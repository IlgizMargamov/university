﻿namespace Clones
{
    public class Clone
    {
        private readonly Stack learnedPrograms;
        private readonly Stack forgottenPrograms;

        public Clone()
        {
            learnedPrograms = new Stack();
            forgottenPrograms = new Stack();
        }

        public Clone(Clone anotherClone)
        {
            learnedPrograms = new Stack(anotherClone.learnedPrograms);
            forgottenPrograms = new Stack(anotherClone.forgottenPrograms);
        }

        public void Learn(int programNumber)
        {
            forgottenPrograms.Clear();
            learnedPrograms.Push(programNumber);
        }

        public void RollBack()
        {
            forgottenPrograms?.Push(learnedPrograms.Pop());
        }

        public void Relearn()
        {
            learnedPrograms?.Push(forgottenPrograms.Pop());
        }

        public string Check()
        {
            return learnedPrograms?.IsEmpty() == true ? "basic" : learnedPrograms?.Peek().ToString();
        }
    }
}