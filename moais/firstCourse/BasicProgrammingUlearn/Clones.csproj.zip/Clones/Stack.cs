﻿namespace Clones
{
    public class Stack
    {
        private StackItem lastStackItem;

        public Stack()
        {
        }

        public Stack(Stack stack)
        {
            lastStackItem = stack.lastStackItem;
        }

        public void Push(int value)
        {
            lastStackItem = new StackItem(value, lastStackItem);
        }

        public int Pop()
        {
            var value = lastStackItem.StackItemValue;
            lastStackItem = lastStackItem.PreviousItem;
            return value;
        }

        public void Clear()
        {
            lastStackItem = null;
        }

        public bool IsEmpty()
        {
            return lastStackItem == null;
        }

        public int Peek()
        {
            return lastStackItem.StackItemValue;
        }
        
        internal class StackItem
        {
            public readonly int StackItemValue;
            public readonly StackItem PreviousItem;

            public StackItem(int stackItemValue, StackItem previousItem)
            {
                StackItemValue = stackItemValue;
                PreviousItem = previousItem;
            }
        }
    }
}