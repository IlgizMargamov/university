﻿using System;

namespace Recognizer
{
    internal static class SobelFilterTask
    {
        public static double[,] SobelFilter(double[,] g, double[,] sx)
        {
            var width = g.GetLength(0);
            var height = g.GetLength(1);
            var sy = TransposeMatrix(sx);

            var result = new double[width, height];
            var centration = sx.GetLength(0) / 2;
            for (var y = centration; y < height - centration; y++)
            for (var x = centration; x < width - centration; x++)
            {
                var gx = ConvoluteMaxrix(g, sx, x, y, centration);
                var gy = ConvoluteMaxrix(g, sy, x, y, centration);
                result[x, y] = Math.Sqrt(gx * gx + gy * gy);
            }

            return result;
        }
        private static double ConvoluteMaxrix(double[,] source, double[,] core, int x, int y, int center)
        {
            var valueN = 0.0d;
            var length = core.GetLength(0);
            for (var i = 0; i < length; i++)
            for (var j = 0; j < length; j++)
                valueN += core[i, j] * source[x - center + i, y - center + j];

            return valueN;
        }

        private static double[,] TransposeMatrix(double[,] sx)
        {
            var length = sx.GetLength(0);
            var sy = new double[length, length];
            for (var x = 0; x < length; x++)
            for (var y = 0; y < length; y++)
                sy[x, y] = sx[y, x];
            return sy;
        }
    }
}