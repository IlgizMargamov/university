﻿using System;

namespace Recognizer
{
    public static class GrayscaleTask
    {
        public static double[,] ToGrayscale(Pixel[,] original)
        {
            var redCoef = 0.299;
            var greenCoef = 0.587;
            var blueCoef = 0.114;
            var divider = 255;
            var width = original.GetLength(0);
            var height = original.GetLength(1);
            var grayPic = new double [width, height];
            for (var y = 0; y < height; y++)
            {
                for (var x = 0; x < width; x++)
                    grayPic[x, y] = (original[x, y].R * redCoef + original[x, y].B * blueCoef +
                                     original[x, y].G * greenCoef) / divider;
            }

            return grayPic;
        }
    }
}