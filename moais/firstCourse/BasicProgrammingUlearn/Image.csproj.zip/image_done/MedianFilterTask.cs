﻿using System.Collections.Generic;
using System.Linq;

namespace Recognizer
{
    internal static class MedianFilterTask
    {
        public static double[,] MedianFilter(double[,] original)
        {
            var width = original.GetLength(0);
            var height = original.GetLength(1);
            var noNoisePic = new double[width, height];

            for (var y = 0; y < height; y++)
            for (var x = 0; x < width; x++)
                noNoisePic[x, y] = DevelopNoNoisePixel(x, y, original, width, height);
            return noNoisePic;
        }

        private static double DevelopNoNoisePixel(int x, int y, double[,] original, int width, int height)
        {
            var pixels = new List<double>();

            for (var i = 0; i < 3; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    x = x - 1 + i;
                    y = y - 1 + j;
                    if (PixelIsInArray(x, y, width, height))
                        pixels.Add(original[x, y]);
                    x = x + 1 - i;
                    y = y + 1 - j;
                }
            }

            return ChooseMedianPixel(pixels);
        }

        private static double ChooseMedianPixel(List<double> pixels)
        {
            pixels.Sort();
            if (pixels.Count % 2 == 0)
                return (pixels[(pixels.Count / 2) - 1] + pixels[pixels.Count / 2]) / 2;
            else
                return pixels[pixels.Count / 2];
        }

        private static bool PixelIsInArray(int x, int y, int width, int height)
        {
            return x > -1 && x < width && y > -1 && y < height;
        }
    }
}