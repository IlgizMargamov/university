﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Recognizer
{
    public static class ThresholdFilterTask
    {
        public static double[,] ThresholdFilter(double[,] original, double whitePixelsFraction)
        {
            var width = original.GetLength(0);
            var height = original.GetLength(1);
            var whiteBlackPic = new double [width, height];
            var pixelsInImage = width * height;
            var pixelsToWhiteOut = (int) (whitePixelsFraction * pixelsInImage);

            var list = GetSortedList(original, height, width);
            var threshold = EstimateThresholdValue(pixelsToWhiteOut, pixelsInImage, list);

            FilterPixels(original, height, width, whiteBlackPic, threshold);
            return whiteBlackPic;
        }

        private static void FilterPixels(double[,] original, int height, int width, double[,] whiteBlackPic,
            double threshold)
        {
            for (var y = 0; y < height; y++)
            for (var x = 0; x < width; x++)
                whiteBlackPic[x, y] = (original[x, y] >= threshold) ? 1.0 : 0.0;
        }

        private static double EstimateThresholdValue(int pixelsToWhiteOut, int pixelsInImage, List<double> list)
        {
            var threshold = 0.0;
            if (pixelsToWhiteOut == pixelsInImage) threshold = double.NegativeInfinity;
            else if (pixelsToWhiteOut == 0) threshold = double.PositiveInfinity;
            else threshold = list[Math.Max(pixelsInImage - pixelsToWhiteOut, 0)];
            return threshold;
        }

        private static List<double> GetSortedList(double[,] original, int height, int width)
        {
            var list = new List<double>();
            for (var y = 0; y < height; y++)
            for (var x = 0; x < width; x++)
                list.Add(original[x, y]);
            list.Sort();
            return list;
        }
    }
}