﻿using System.Collections.Generic;
using System.Linq;

namespace PocketGoogle
{
    public class Indexer : IIndexer
    {
        private Dictionary<string, Dictionary<int, List<int>>> posWordInDocs =
            new Dictionary<string, Dictionary<int, List<int>>>();

        public void Add(int id, string documentText)
        {
            var text = documentText.Split(new[] {' ', '.', ',', '!', '?', ':', '-', '\r', '\n'});
            var ind = 0;
            foreach (var word in text)
            {
                if (!posWordInDocs.ContainsKey(word)) posWordInDocs[word] = new Dictionary<int, List<int>>();
                if (!posWordInDocs[word].ContainsKey(id)) posWordInDocs[word][id] = new List<int>();
                posWordInDocs[word][id].Add(ind);
                ind += word.Length + 1;
            }
        }

        public List<int> GetIds(string word) =>
            posWordInDocs.ContainsKey(word) ? posWordInDocs[word].Keys.ToList() : new List<int>();

        public List<int> GetPositions(int id, string word) =>
            posWordInDocs.ContainsKey(word) && posWordInDocs[word].ContainsKey(id)
                ? posWordInDocs[word][id].ToList()
                : new List<int>();

        public void Remove(int id)
        {
            foreach (var e in posWordInDocs) e.Value.Remove(id);
        }
    }
}