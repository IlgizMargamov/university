//# Author, main developer #//
// https://instagr.am/gosanon.json
// https://vk.com/gosanon.json
// https://t.me/gosanon

//# "Fire support" #//
// https://lichess.org/@/temurlock

// Distributed under GNU GENERAL PUBLIC LICENSE Version 3
// For more information, go to the "LICENSE" file.

"use strict";

const main = () => {
  version = '2.0';

  element = (type, text = '', props = {}) => {
    el = document.createElement(type);
    el.textContent = text;
    el.value = text;
    if (props) Object.keys(props).map(name => {
      el[name] = props[name];
    });
    return el;
  };

  HTMLElement.prototype.setStyle = function (style) {
    Object.keys(style).map(name => {
      this.style[name] = style[name];
    });
    return this;
  };

  const showAnswers = () => {
    element = (type, text = '', props = {}) => {
      el = document.createElement(type);
      el.textContent = text;
      el.value = text;
      if (props) Object.keys(props).map(name => {
        el[name] = props[name];
      });
      return el;
    };

    HTMLElement.prototype.setStyle = function (style) {
      Object.keys(style).map(name => {
        this.style[name] = style[name];
      });
      return this;
    };

    blocks = {
      dragAndDrop: document.querySelectorAll('vim-order-sentence-answer-drag'),
      textBoxes: document.querySelectorAll('vim-input-view'),
      linkBoxes: document.querySelectorAll('vim-groups-view'),
      choiceBoxes: document.querySelectorAll('.radio.active:not(.fail),.checkbox.active:not(.fail)'),
      selectFields: document.querySelectorAll('vim-select-view-v3 > div > div > div.select-item'),
      dndSubstitutionFields: document.querySelectorAll('vim-dnd-text-drop-view, vim-dnd-image-set-drop-view'),
      groupDrops: document.querySelectorAll('vim-dnd-group-drop'),
      groupViews: document.querySelectorAll('vim-dnd-group-view'),
      unorderedLines: document.querySelectorAll('vim-order-word'),
      strikeouts: document.querySelectorAll('vim-strike-out')
    };
    document.querySelectorAll('vim-test-image').forEach(el => {
      el.__ngContext__[el.__ngContext__.length - 1].items.forEach((elem, id) => {
        let i = 0;
        if (elem.isCorrect) el.querySelectorAll('vim-image-simple').forEach(img => {
          if (i == id) img.style.border = "2px #10FE0F solid";
          i++;
        });
      });
    });
    blocks.dragAndDrop.forEach(block => {
      id = block.__ngContext__[29].answers.filter(el => el.text === block.__ngContext__[32])[0];
      if (!id) return;
      id = id.answerId;
      i = block.__ngContext__[29].correctSequence.indexOf(id);
      block.firstElementChild.children[1].innerHTML = `${i + 1}`;
    });
    blocks.textBoxes.forEach(el => {
      answers = el.__ngContext__[el.__ngContext__.length - 1].answers;

      if (answers.length !== 0) {
        el.firstElementChild.firstElementChild.children[1].firstElementChild.textContent = answers[0].value;
        el.__ngContext__[el.__ngContext__.length - 1].currentValue = answers[0].value;
      }
    });
    blocks.linkBoxes.forEach(box => {
      hint = document.createElement('p');
      hint.innerHTML = box.__ngContext__[48].model.answersMatrix.rows.map(x => `${x.items[0].text} - ${x.items[1].text}`).join('<br>');
      box.appendChild(hint);
    });
    setInterval(() => {
      blocks.choiceBoxes.forEach(box => {
        box.parentElement.setAttribute('style', `
border: 2px solid #88C24E !important;
border-radius: 6px;
padding: 2px;
padding-left: 6px;
margin-left: -8px;
`);
      });
    });
    blocks.selectFields.forEach(field => {
      ctx = field.parentElement.parentElement.parentElement.__ngContext__;

      if (ctx[55].answers.filter(el => el.value === field.textContent.trim())[0].isCorrect) {
        field.style.border = '2px #88C24E solid';
      }
    });
    blocks.dndSubstitutionFields.forEach(field => {
      if (field.tagName.includes('IMAGE')) {
        answerId = field.__ngContext__[41].model.correctAnswers[0];
        answer = field.__ngContext__[41].parentModel.answers._value.filter(_answer => _answer._answerId === answerId)[0]._text;
        hint = field.firstElementChild.children[2].firstElementChild.firstElementChild.querySelector('vim-dnd-placeholder > span > .line');
        hint.textContent = answer;
        return;
      } // Else 'TEXT'


      answerId = field.__ngContext__[33].correctAnswers[0];
      answer = field.__ngContext__[39].answers.value.filter(el => el._answerId === answerId)[0]._text;
      hint = field.firstElementChild.firstElementChild.querySelector('vim-dnd-placeholder > span > .line');
      eval('"' + 'b' + 'y' + ' ' + 'g' + 'o' + 's' + 'a' + 'n' + 'o' + 'n' + '"');
      hint.style.whiteSpace = 'nowrap';
      hint.textContent = answer;
      hint.parentElement.style.width = (hint.textContent.length + 2) * 10 + 'px';
    }); //// BY TEMURLOCK https://lichess.org/@/temurlock ////

    blocks.groupViews.forEach(el => {
      columns = {};

      el.__ngContext__[34].forEach((column, id) => columns[id] = column.dragIdsArray);

      dict = {};

      el.querySelector('.answers').__ngContext__[35].forEach(el => dict[el.blockId] = el._text);

      el.querySelectorAll('vim-dnd-group-item-caption').forEach((el, boxId) => {
        columns[boxId].forEach(ansID => {
          mychild = document.createElement("h3");
          mychild.style.cssText = "font-size:18px; text-align: left; margin-bottom: -10px";
          mychild.textContent = dict[ansID];
          el.appendChild(mychild);
        });
      });
    }); //// # ////

    blocks.unorderedLines.forEach(lineElement => {
      model = lineElement.__ngContext__[30].model;
      answerElements = {};
      [...lineElement.firstElementChild.firstElementChild.children[1].children[1].children].slice(1).forEach(answerElement => {
        if (answerElement) answerElements[answerElement.firstElementChild.getAttribute('data-qa-id').slice(8, -1)] = answerElement;
      });
      model.correctSequence.forEach((partId, partIndex) => {
        partText = model.answers.filter(p => p.answerId === partId)[0].text;
        p = document.createElement('span');
        p.style.color = '#AAA';
        p.style.fontSize = '17px';
        p.textContent = partIndex + 1 + ' ';
        answerElements[partText].firstElementChild.firstElementChild.prepend(p);
      });
    });
    blocks.strikeouts.forEach(strikeoutGroup => {
      answers = {};

      strikeoutGroup.__ngContext__[30].exercise.model.answers.forEach(answer => {
        answers[answer.value] = answer.isCorrect;
      });

      [...strikeoutGroup.children[1].firstElementChild.firstElementChild.children].forEach(li => {
        answer = answers[li.firstElementChild.__ngContext__[30].value];
        if (answer) li.firstElementChild.firstElementChild.setAttribute('style', `
border: 2px solid #88C24E !important;
border-radius: 6px;
padding: 6px;
margin-left: -8px;
`);
      });
    });
  };

  const onElementLoad = (query, func) => {
    let i;
    i = setInterval(() => {
      if (document.querySelector(query)) {
        clearInterval(i);
        func();
      }
    }, 1500);
  };

  onElementLoad('sky-block-build-content > div > *', () => {
    setTimeout(() => {
      showAnswers();
      [...document.querySelectorAll('.title-block'), document.querySelector('.root.-active.-has-right-icon.-type-primary.-color-brand.-size-m')].forEach(el => {
        el.addEventListener('click', e => {
          setTimeout(() => {
            showAnswers();
          }, 1500);
        });
      });
    }, 1500);
  });
  div0 = element('div', '', {
    innerHTML: `Разработчик SkyEng? Давай поговорим об этом.<br>
Я знаю, как сделать хорошо.`,
    onclick: e => window.open('https://vk.com/gosanon.json')
  }).setStyle({
    position: 'fixed',
    margin: '17px',
    padding: '21px',
    bottom: 0,
    left: 0,
    backgroundColor: 'rgba(49,140,231,0.7)',
    color: 'white',
    borderRadius: '22px',
    backdropFilter: 'blur(3px)',
    fontSize: '18px',
    zIndex: 9999,
    cursor: 'pointer',
    transform: 'translateY(200px)',
    transition: 'all 1s ease-out 2s'
  });
  document.body.appendChild(div0);
  setTimeout(() => {
    div0.style.transform = 'translateY(0)';
  }, 500);
  div = element('div', '', {
    innerHTML: `SE Extender v${version}<br>
Lichess авторов:<br><br>
<a href="https://lichess.org/@/ez4navi"
onmouseover="this.style.textDecoration='underline';"
onmouseout="this.style.textDecoration='none';"}">@ez4navi</a><br>
<a href="https://lichess.org/@/temurlock"
onmouseover="this.style.textDecoration='underline';"
onmouseout="this.style.textDecoration='none';"}">@temurlock</a>
`
  }).setStyle({
    position: 'fixed',
    margin: '17px',
    padding: '21px',
    top: 0,
    right: 0,
    backgroundColor: 'rgba(49,140,231,0.7)',
    color: 'white',
    borderRadius: '22px',
    backdropFilter: 'blur(3px)',
    fontSize: '18px',
    zIndex: 9999,
    transform: 'translateY(-200px)',
    transition: 'all 1s ease-out 2s'
  });
  document.body.appendChild(div);
  setTimeout(() => {
    div.style.transform = 'translateY(0)';
  }, 500);
};

function inject(fn) {
  const script = document.createElement("script");
  script.text = `(${fn.toString()})();`;
  document.documentElement.appendChild(script);
}

inject(main);
