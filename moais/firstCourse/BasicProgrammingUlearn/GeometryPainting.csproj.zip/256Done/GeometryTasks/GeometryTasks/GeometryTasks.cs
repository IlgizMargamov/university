﻿using System;

namespace ReadOnlyVectorTask
{
    public class ReadOnlyVector
    {
        public readonly double Y { get; set; }
        public readonly double X { get; set; }

        public ReadOnlyVector(double x, double y)
        {
            X = x;
            Y = y;
        }

        public ReadOnlyVector Add(ReadOnlyVector vector)
        {
            return new ReadOnlyVector(X + vector.X, Y + vector.Y);
        }

        public ReadOnlyVector WithX(double x)
        {
            return new ReadOnlyVector(x, Y);
        }

        public ReadOnlyVector WithY(double y)
        {
            return new ReadOnlyVector(X, y);
        }
    }
}

namespace GeometryTasks
{
    public class Vector
    {
        public double X;
        public double Y;

        public double GetLength()
        {
            return Geometry.GetLength(this);
        }

        public Vector Add(Vector vector)
        {
            return Geometry.Add(this, vector);
        }

        public bool Belongs(Segment segment)
        {
            return Geometry.IsVectorInSegment(this, segment);
        }
    }


    public class Segment
    {
        public Vector Begin;
        public Vector End;


        public bool Contains(Vector vector)
        {
            return Geometry.IsVectorInSegment(vector, this);
        }

        public double GetLength()
        {
            return Geometry.GetLength(this);
        }
    }

    public class Geometry
    {
        public static bool IsVectorInSegment(Vector vector, Segment segment)
        {
            // using.DistanceTask just find any zero-length sides of the two triangles.
            var segmentLength = Geometry.GetLength(segment);
            var ac = GetLength(new Vector {X = segment.Begin.X - vector.X, Y = segment.Begin.Y - vector.Y});
            var bc = GetLength(new Vector {X = segment.End.X - vector.X, Y = segment.End.Y - vector.Y});
            var length = ac + bc;
            return Math.Abs(length - segmentLength) < 1e-2;
        }

        public static double GetLength(Segment segment)
        {
            var beginEndX = segment.Begin.X - segment.End.X;
            var beginEndY = segment.Begin.Y - segment.End.Y;
            return Math.Sqrt(beginEndX * beginEndX + beginEndY * beginEndY);
        }

        public static double GetLength(Vector vector)
        {
            return Math.Sqrt(vector.X * vector.X + vector.Y * vector.Y);
        }

        public static Vector Add(Vector vector1, Vector vector2)
        {
            return new Vector {X = vector1.X + vector2.X, Y = vector1.Y + vector2.Y};
        }
    }
}