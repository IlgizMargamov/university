﻿using System;
using System.Collections.Generic;
using System.Drawing;
using GeometryTasks;

namespace GeometryPainting
{
    public static class SegmentExtensions
    {
        private static readonly Dictionary<Segment, Color> dict = new Dictionary<Segment, Color>();

        public static void SetColor(this Segment segment, Color color)
        {
            if (dict.Count == 0)
                dict.Add(segment, color);
            else
            {
                if (dict.ContainsKey(segment))
                    dict.Remove(segment);
                dict.Add(segment, color);
            }
            GC.Collect();
        }

        public static Color GetColor(this Segment segment)
        {
            if (segment == null) return Color.Black;
            return dict.TryGetValue(segment, out var value) ? dict[segment] : Color.Black;
        }
    }
}