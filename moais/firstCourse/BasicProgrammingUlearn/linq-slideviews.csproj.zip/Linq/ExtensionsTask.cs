﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace linq_slideviews
{
    public static class ExtensionsTask
    {
        /// <summary>
        /// Медиана списка из нечетного количества элементов — это серединный элемент списка после сортировки.
        /// Медиана списка из четного количества элементов — это среднее арифметическое 
        /// двух серединных элементов списка после сортировки.
        /// </summary>
        /// <exception cref="InvalidOperationException">Если последовательность не содержит элементов</exception>
        public static double Median(this IEnumerable<double> items)
        {
            var list = items.ToList();
            if (!list.Any()) throw new InvalidOperationException();
            list.Sort();
            var listCountFrom0 = list.Count - 1;
            var listCountFrom0Halved = listCountFrom0 / 2;
            return (listCountFrom0 + 1) % 2 == 0
                ? (list[listCountFrom0Halved] + list[listCountFrom0Halved + 1]) / 2.0
                : list[listCountFrom0Halved];
        }

        /// <returns>
        /// Возвращает последовательность, состоящую из пар соседних элементов.
        /// Например, по последовательности {1,2,3} метод должен вернуть две пары: (1,2) и (2,3).
        /// </returns>
        public static IEnumerable<Tuple<T, T>> Bigrams<T>(this IEnumerable<T> items)
        {
            var iterator = items.GetEnumerator();
            iterator.MoveNext();
            var current = iterator.Current;
            while (iterator.MoveNext())
            {
                yield return Tuple.Create(current, iterator.Current);
                current = iterator.Current;
            }
        }
    }
}