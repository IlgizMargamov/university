﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace linq_slideviews
{
    public class StatisticsTask
    {
        public static double GetMedianTimePerSlide(List<VisitRecord> visits, SlideType slideType)
        {
            return visits
                .GroupBy(record => record.UserId)
                .Select(visitRecords => visitRecords
                    .OrderBy(visitRecord => visitRecord.DateTime)
                    .Bigrams())
                .Select(bigram =>
                {
                    return bigram
                        .Where(visit => visit.Item1.UserId.Equals(visit.Item2.UserId))
                        .Where(record => record.Item1.SlideType == slideType)
                        .Select(visit => visit.Item2.DateTime.Subtract(visit.Item1.DateTime).TotalMinutes);
                })
                .SelectMany(x => x)
                .Where(time => 120 >= time && time >= 1)
                .ToList()
                .DefaultIfEmpty(0)
                .Median();
        }
    }
}