﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace linq_slideviews
{
    public class ParsingTask
    {
        /// <param name="lines">все строки файла, которые нужно распарсить. Первая строка заголовочная.</param>
        /// <returns>Словарь: ключ — идентификатор слайда, значение — информация о слайде</returns>
        /// <remarks>Метод должен пропускать некорректные строки, игнорируя их</remarks>
        public static IDictionary<int, SlideRecord> ParseSlideRecords(IEnumerable<string> lines)
        {
            return lines
                .Skip(1)
                .Select(z => z.Split(';'))
                .Select(line =>
                {
                    if (line.Length != 3 || !int.TryParse(line[0], out var slideId) ||
                        !Enum.TryParse<SlideType>(line[1], true, out var slideType)) return null;
                    return new SlideRecord(slideId, slideType, line[2]);
                })
                .Where(record => record != null)
                .ToDictionary(slideRecord => slideRecord.SlideId);
        }

        /// <param name="lines">все строки файла, которые нужно распарсить. Первая строка — заголовочная.</param>
        /// <param name="slides">Словарь информации о слайдах по идентификатору слайда. 
        /// Такой словарь можно получить методом ParseSlideRecords</param>
        /// <returns>Список информации о посещениях</returns>
        /// <exception cref="FormatException">Если среди строк есть некорректные</exception>
        public static IEnumerable<VisitRecord> ParseVisitRecords(
            IEnumerable<string> lines, IDictionary<int, SlideRecord> slides)
        {
            return lines
                .Skip(1)
                .Select(line =>
                {
                    var info = line.Split(';');
                    if (info.Length != 4 || !DateTime.TryParseExact(info[2] + ' ' + info[3], "yyyy-MM-dd HH:mm:ss",
                            CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateTime) ||
                        !int.TryParse(info[0], out var userId) || !int.TryParse(info[1], out var slideId) ||
                        !slides.ContainsKey(slideId))
                        throw new FormatException($"Wrong line [{line}]");
                    return new VisitRecord(userId, slideId, dateTime, slides[slideId].SlideType);
                });
        }
    }
}