using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace rocket_bot
{
    public class Channel<T> where T : class
    {
        /// <summary>
        /// Возвращает количество элементов в коллекции
        /// </summary>
        public int Count => queue.Count;

        private ConcurrentQueue<T> queue = new ConcurrentQueue<T>();
        private T last;
        
        /// <summary>
        /// Возвращает последний элемент или null, если такого элемента нет
        /// </summary>
        public T LastItem() => last;

        /// <summary>
        /// Возвращает элемент по индексу или null, если такого элемента нет.
        /// При присвоении удаляет все элементы после.
        /// Если индекс в точности равен размеру коллекции, работает как Append.
        /// </summary>
        public T this[int index]
        {
            get => queue.ElementAtOrDefault(index);
            set
            {
                if (index == queue.Count - 1) AppendIfLastItemIsUnchanged(value, last);

                var newQueue = new ConcurrentQueue<T>(queue.Take(index));
                queue = newQueue;
                queue.Enqueue(value);
            }
        }


        /// <summary>
        /// Добавляет item в конец только если lastItem является последним элементом
        /// </summary>
        public void AppendIfLastItemIsUnchanged(T item, T knownLastItem)
        {
            if (knownLastItem != last) return;
            queue.Enqueue(item);
            last = item;
        }
    }

    public class ChannelQueue<T> where T : class
    {
        private Queue<T> queue = new Queue<T>();
        private T last;

        /// <summary>
        /// Возвращает элемент по индексу или null, если такого элемента нет.
        /// При присвоении удаляет все элементы после.
        /// Если индекс в точности равен размеру коллекции, работает как Append.
        /// </summary>
        public T this[int index]
        {
            get
            {
                lock (queue)
                {
                    return queue.ElementAtOrDefault(index);
                }
            }
            set
            {
                lock (queue)
                {
                    if (index == queue.Count - 1) AppendIfLastItemIsUnchanged(value, last);

                    var newQueue = new Queue<T>(queue.Take(index));
                    queue = newQueue;
                    queue.Enqueue(value);
                }
            }
        }

        /// <summary>
        /// Возвращает последний элемент или null, если такого элемента нет
        /// </summary>
        public T LastItem()
        {
            lock (queue)
            {
                return last;
            }
        }

        /// <summary>
        /// Добавляет item в конец только если lastItem является последним элементом
        /// </summary>
        public void AppendIfLastItemIsUnchanged(T item, T knownLastItem)
        {
            lock (queue)
            {
                if (knownLastItem != last) return;
                queue.Enqueue(item);
                last = item;
            }
        }

        /// <summary>
        /// Возвращает количество элементов в коллекции
        /// </summary>
        public int Count
        {
            get
            {
                lock (queue)
                {
                    return queue.Count;
                }
            }
        }
    }
}