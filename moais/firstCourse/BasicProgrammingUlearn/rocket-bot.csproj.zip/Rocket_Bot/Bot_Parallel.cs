using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace rocket_bot
{
    public partial class Bot
    {
        public Rocket GetNextMove(Rocket rocket)
        {
            var taskArr = new Task<Rocket>[threadsCount];
            for (var i = 0; i < taskArr.Length; i++)
            {
                taskArr[i] = new Task<Rocket>(() =>
                {
                    var bestMove = SearchBestMove(rocket, new Random(), iterationsCount / threadsCount);
                    return rocket.Move(bestMove.Item1, level);
                });
                taskArr[i].Start();
            }

            Task.WhenAll(taskArr);
            return taskArr.OrderBy(task => task.Result.Time).First().Result;
        }
    }
}