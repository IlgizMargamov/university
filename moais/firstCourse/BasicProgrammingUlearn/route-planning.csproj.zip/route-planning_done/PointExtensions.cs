using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using RoutePlanning;

namespace RoutePlanning
{
    public static class PointExtensions
    {
        public static double GetPathLength(this Point[] checkpoints, int[] order)
        {
            var prevPoint = checkpoints[order[0]];
            var len = 0.0;
            foreach (var checkpointIndex in order.Skip(1))
            {
                len += prevPoint.DistanceTo(checkpoints[checkpointIndex]);
                prevPoint = checkpoints[checkpointIndex];
            }

            return len;
        }


        public static double DistanceTo(this Point a, Point b)
        {
            var dx = a.X - b.X;
            var dy = a.Y - b.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}



namespace RoutePlanning1
{
    public static class PathFinderTask
    {
        public static int[] FindBestCheckpointsOrder(
            Point[] checkpoints)
        {
            double shortestDistance = double.PositiveInfinity;
            int[] order = new int[checkpoints.Length];
            int[] bestOrder = new int[checkpoints.Length];
            MakePermutations(order, 1, checkpoints, ref shortestDistance, ref bestOrder);
            return bestOrder;
        }

        public static int[] MakePermutations(int[] order, int size, Point[] checkpoints,
            ref double shortestDistance, ref int[] bestOrder)
        {
            var currentOrder = new int[size];
            Array.Copy(order, currentOrder, size);
            var pathLength = PointExtensions.GetPathLength(checkpoints, currentOrder);

            if (!(pathLength < shortestDistance)) return order;
            if (size == order.Length)
            {
                shortestDistance = pathLength;
                bestOrder = (int[])order.Clone();
                return order;
            }


            for (int i = 1; i < order.Length; i++)
            {
                var index = Array.IndexOf(order, i, 0, size);
                if (index != -1)
                    continue;
                order[size] = i;
                MakePermutations(order, size + 1, checkpoints, ref shortestDistance,
                    ref bestOrder);
            }

            return order;
        }
    }
}