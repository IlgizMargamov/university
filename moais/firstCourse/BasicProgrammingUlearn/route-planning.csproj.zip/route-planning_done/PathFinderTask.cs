using System;
using System.Drawing;

namespace RoutePlanning
{
    public static class PathFinderTask
    {
        public static int[] FindBestCheckpointsOrder(Point[] checkpoints)
        {
            var checkpointsLength = checkpoints.Length;
            var quickestWay = double.PositiveInfinity;
            var order = new int[checkpointsLength];
            var orderToUse = new int[checkpointsLength];
            MakeTrivialPermutation(1, order, orderToUse, ref quickestWay, checkpoints);
            return orderToUse;
        }

        private static void MakeTrivialPermutation(int position, int[] order, int[] orderToUse, ref double quickestWay,
            Point[] checkPoints)
        {
            var tmpOrder = new int[position];
            Array.Copy(order, tmpOrder, position);
            var len = checkPoints.GetPathLength(tmpOrder);
            var orderLength = order.Length;

            if (!(len < quickestWay)) return;
            if (position != orderLength)
            {
                for (var i = 1; i < orderLength; i++)
                {
                    var symbolIndex = Array.IndexOf(order, i, 0, position);
                    if (symbolIndex != -1) continue;
                    order[position] = i;
                    MakeTrivialPermutation(position + 1, order, orderToUse, ref quickestWay, checkPoints);
                }

                return;
            }

            quickestWay = len;
            Array.Copy(order, orderToUse, position);
        }
    }
}