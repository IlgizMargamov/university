﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelAccounting
{
    public class AccountingModel : ModelBase
    {
        private double price;
        private int nightsCount;
        private double discount;
        private double total;

        public AccountingModel()
        {
            price = 0;
            nightsCount = 1;
            discount = 0;
            total = 0;
        }


        public double Price
        {
            get => price;
            set
            {
                if (value >= 0) price = value;
                else throw new ArgumentException();
                ResetTotal();
                Notify(nameof(Price));
            }
        }

        public int NightsCount
        {
            get => nightsCount;
            set
            {
                if (value > 0) nightsCount = value;
                else throw new ArgumentException();
                ResetTotal();
                Notify(nameof(NightsCount));
            }
        }

        public double Discount
        {
            get => discount;
            set
            {
                discount = value;
                if (!discount.Equals((-1 * Total / (Price * NightsCount) + 1) * 100))
                    ResetTotal();
                Notify(nameof(Discount));
            }
        }

        public double Total
        {
            get => total;
            set
            {
                if (value > 0) total = value;
                else throw new ArgumentException();
                if (!total.Equals(Price * NightsCount * (1 - Discount / 100)))
                    ResetDiscount();
                Notify(nameof(Total));
            }
        }

        private void ResetDiscount()
        {
            Discount = (-1 * Total / (Price * NightsCount) + 1) * 100;
        }

        private void ResetTotal()
        {
            Total = Price * NightsCount * (1 - Discount / 100);
        }
    }
}