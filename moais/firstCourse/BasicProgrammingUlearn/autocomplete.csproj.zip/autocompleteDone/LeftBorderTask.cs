﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Autocomplete
{
    public class LeftBorderTask
    {
        public static int GetLeftBorderIndex(IReadOnlyList<string> phrases, string prefix, int left, int right)
        {
            var rightToLeft = right - left;
            if (rightToLeft <= 1) return left;
            var middleIndex = left + rightToLeft / 2;
            return string.Compare(prefix, phrases[middleIndex], StringComparison.OrdinalIgnoreCase) > 0
                ? GetLeftBorderIndex(phrases, prefix, middleIndex, right)
                : GetLeftBorderIndex(phrases, prefix, left, middleIndex);
        }
    }
}