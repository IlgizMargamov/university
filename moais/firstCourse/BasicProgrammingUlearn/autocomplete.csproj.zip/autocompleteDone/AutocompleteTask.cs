﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Autocomplete
{
    [TestFixture]
    public class AutocompleteTests
    {
        [Test]
        public void TopByPrefix_IsEmpty_WhenPhrasesAre()
        {
            var phrases = new List<string> {"a", "ab", "abc", "b"};
            var prefix = "c";
            var count = 4;
            CollectionAssert.IsEmpty(AutocompleteTask.GetTopByPrefix(phrases, prefix, count));
        }

        [Test]
        public void TopByPrefix_IsEmpty_WhenNoPhrases()
        {
            var phrases = new List<string>();
            var prefix = "a";
            var count = 4;
            CollectionAssert.IsEmpty(AutocompleteTask.GetTopByPrefix(phrases, prefix, count));
        }

        [Test]
        public void TopByPrefix_Is_WhenPhrasesAre()
        {
            var phrases = new List<string>() {"a", "ab", "abc", "b"};
            var prefix = "a";
            var count = 4;
            var expectedResult = new List<string>() {"a", "ab", "abc"};
            var actualResult = AutocompleteTask.GetTopByPrefix(phrases, prefix, count);
            CollectionAssert.AreEqual(expectedResult, actualResult);
        }

        [Test]
        public void TopByPrefix_IsTotal_WhenPhrasesAre_WhenPrefixIsEmpty()
        {
            var phrases = new List<string>() {"a", "ab", "abc", "b"};
            var prefix = "";
            var count = 4;
            var expectedResult = new List<string>() {"a", "ab", "abc", "b"};
            var actualResult = AutocompleteTask.GetTopByPrefix(phrases, prefix, count);
            CollectionAssert.AreEqual(expectedResult, actualResult);
        }

        [Test]
        public void TopByPrefix_IsTotal_WhenPhrasesAre_WhenPrefixIs()
        {
            var phrases = new List<string>() {"a", "ab", "abc", "abcd"};
            var prefix = "a";
            var count = 4;
            var expectedResult = new List<string>() {"a", "ab", "abc", "abcd"};
            var actualResult = AutocompleteTask.GetTopByPrefix(phrases, prefix, count);
            CollectionAssert.AreEqual(expectedResult, actualResult);
        }

        [Test]
        public void TopByPrefix_IsTotal_WhenPhrasesAre_WhenPrefixIs_CountNotTotal()
        {
            var phrases = new List<string>() {"a", "ab", "abc", "abcd"};
            var prefix = "a";
            var count = 2;
            var expectedResult = new List<string>() {"a", "ab"};
            var actualResult = AutocompleteTask.GetTopByPrefix(phrases, prefix, count);
            CollectionAssert.AreEqual(expectedResult, actualResult);
        }

        [Test]
        public void CountByPrefix_IsTotalCount_WhenEmptyPrefix()
        {
            var phrases = new List<string> {"a", "ab", "abc", "b"};
            var prefix = "";
            var expectedCount = 4;
            var actualCount = AutocompleteTask.GetCountByPrefix(phrases, prefix);
            Assert.AreEqual(expectedCount, actualCount);
        }

        [Test]
        public void CountByPrefix_Is_WhenPrefixIs()
        {
            var phrases = new List<string> {"a", "ab", "abc", "b"};
            var prefix = "a";
            var expectedCount = 3;
            var actualCount = AutocompleteTask.GetCountByPrefix(phrases, prefix);
            Assert.AreEqual(expectedCount, actualCount);
        }

        [Test]
        public void CountByPrefix_IsEmpty_WhenPrefixIs()
        {
            var phrases = new List<string> {"a", "ab", "abc", "b"};
            var prefix = "c";
            var expectedCount = 0;
            var actualCount = AutocompleteTask.GetCountByPrefix(phrases, prefix);
            Assert.AreEqual(expectedCount, actualCount);
        }
    }

    internal class AutocompleteTask
    {
        public static string FindFirstByPrefix(IReadOnlyList<string> phrases, string prefix)
        {
            var index = LeftBorderTask.GetLeftBorderIndex(phrases, prefix, -1, phrases.Count) + 1;
            if (index < phrases.Count && phrases[index].StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                return phrases[index];

            return null;
        }

        public static string[] GetTopByPrefix(IReadOnlyList<string> phrases, string prefix, int count)
        {
            var wordsToReturn = Math.Min(GetCountByPrefix(phrases, prefix), count);
            var output = new string[wordsToReturn];
            for (var i = 0; i < wordsToReturn; i++)
            {
                var startIndex = LeftBorderTask.GetLeftBorderIndex(phrases, prefix, -1 + i, phrases.Count) + 1;
                output[i] = phrases[startIndex];
            }

            return output;
        }

        public static int GetCountByPrefix(IReadOnlyList<string> phrases, string prefix)
        {
            var phrasesCount = phrases.Count;
            var leftBorder = LeftBorderTask.GetLeftBorderIndex(phrases, prefix, -1, phrasesCount);
            var rightBorder = RightBorderTask.GetRightBorderIndex(phrases, prefix, -1, phrasesCount);
            return rightBorder - leftBorder - 1;
        }
    }
}