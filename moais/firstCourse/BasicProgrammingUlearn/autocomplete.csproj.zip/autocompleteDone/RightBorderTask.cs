﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Autocomplete
{
    public class RightBorderTask
    {
        public static int GetRightBorderIndex(IReadOnlyList<string> phrases, string prefix, int left, int right)
        {
            while (right - left > 1)
            {
                var middleIndex = left + (right - left) / 2;
                if (string.Compare(prefix, phrases[middleIndex], StringComparison.OrdinalIgnoreCase) >= 0
                    || phrases[middleIndex].StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) left = middleIndex;
                else right = middleIndex;
            }

            return right;
        }
    }
}