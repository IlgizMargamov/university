using System;
using System.Collections.Generic;
using System.Linq;
using Greedy.Architecture;
using System.Drawing;

namespace Greedy
{
    public class DijkstraPathFinder
    {
        public IEnumerable<PathWithCost> GetPathsByDijkstra(State state, Point start, IEnumerable<Point> targets)
        {
            var track = new Dictionary<Point, DijkstraData> {{start, new DijkstraData(0, zero)}};
            var chests = new HashSet<Point>(state.Chests);
            var visited = new List<Point>();
            while (chests.Any())
            {
                var openPoint = CalcOpenPoint(track, visited);
                if (openPoint == zero) break;
                if (chests.Contains(openPoint))
                {
                    yield return CalculatePath(openPoint, track);
                    chests.Remove(openPoint);
                }

                CalculateNeighbours(state, openPoint, track);
                visited.Add(openPoint);
            }
        }

        private PathWithCost CalculatePath(Point openPoint, IReadOnlyDictionary<Point, DijkstraData> track)
        {
            var path = new List<Point>();
            var endPoint = openPoint;
            while (endPoint != zero)
            {
                path.Add(endPoint);
                endPoint = track[endPoint].Previous;
            }

            path.Reverse();
            return new PathWithCost(track[openPoint].Price, path.ToArray());
        }

        private Point CalcOpenPoint(Dictionary<Point, DijkstraData> track, ICollection<Point> visited)
        {
            var bestPrice = int.MaxValue;
            var openPoint = new Point(zero.X, zero.Y);
            foreach (var pair in track.Where(pair => pair.Value.Price < bestPrice && !visited.Contains(pair.Key)))
            {
                openPoint = pair.Key;
                bestPrice = pair.Value.Price;
            }

            return openPoint;
        }

        private static void CalculateNeighbours(State state, Point openPoint, IDictionary<Point, DijkstraData> track)
        {
            for (var dx = -1; dx <= 1; dx++)
            for (var dy = -1; dy <= 1; dy++)
            {
                var point = new Point(openPoint.X + dx, openPoint.Y + dy);
                if (Math.Abs(dx + dy) != 1 || !state.InsideMap(point)) continue;
                var current = track[openPoint].Price + state.CellCost[point.X, point.Y];
                if (!state.IsWallAt(point) && (!track.ContainsKey(point) || track[point].Price > current))
                    track[point] = new DijkstraData(current, openPoint);
            }
        }

        private Point zero = new Point(int.MinValue, int.MinValue);

        private class DijkstraData
        {
            public readonly int Price;
            public Point Previous;

            public DijkstraData(int price, Point previous)
            {
                Price = price;
                Previous = previous;
            }
        }
    }
}