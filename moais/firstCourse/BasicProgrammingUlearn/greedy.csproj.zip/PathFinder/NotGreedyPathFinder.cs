﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Greedy.Architecture;
using Greedy.Architecture.Drawing;

namespace Greedy
{
    public class NotGreedyPathFinder : IPathFinder
    {
        private List<Point> badPath;
        private int worstChestsCount;
        private int chestsCount;

        public List<Point> FindPathToCompleteGoal(State state)
        {
            badPath = new List<Point>();
            worstChestsCount = 0;
            chestsCount = state.Chests.Count;
            FindPath(state, state.Position, 0, 0, state.Chests, new List<Point>());
            return badPath;
        }

        private void FindPath(State state, Point start, int energyWasted, int chest, ICollection<Point> chests,
            List<Point> path)
        {
            if (chest > worstChestsCount)
            {
                worstChestsCount = chest;
                badPath = path;
            }

            if (chest == chestsCount || worstChestsCount == chestsCount) return;
            var pathFinder = new DijkstraPathFinder();
            var list = pathFinder.GetPathsByDijkstra(state, start, chests).ToList();
            foreach (var pathWithCost in list.Where(pathWithCost =>
                pathWithCost.Cost + energyWasted <= state.Energy))
            {
                chests.Remove(pathWithCost.End);
                FindPath(state, pathWithCost.End,
                    pathWithCost.Cost + energyWasted,
                    chest + 1,
                    chests,
                    path.Concat(pathWithCost.Path.Skip(1)).ToList());
                chests.Add(pathWithCost.End);
            }
        }
    }
}