﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Greedy.Architecture;
using Greedy.Architecture.Drawing;

namespace Greedy
{
    public class GreedyPathFinder : IPathFinder
    {
        public List<Point> FindPathToCompleteGoal(State state)
        {
            if (state.Energy == 0 || state.Goal > state.Chests.Count) return new List<Point>();
            var stateInfo = new StateInfo(state.Position, state.Energy, state.Goal);
            var searcher = new DijkstraPathFinder();
            var pathWithCostsList = new List<PathWithCost>();
            while (stateInfo.Goal > 0)
            {
                var path = searcher.GetPathsByDijkstra(state, stateInfo.Start, state.Chests).FirstOrDefault();
                if (path == null || stateInfo.Energy < path.Cost) return new List<Point>();
                pathWithCostsList.Add(path);
                state.Chests.Remove(path.End);
                stateInfo.ChangeValue(1, path.Cost, path.End);
            }

            return pathWithCostsList.SelectMany(x => x.Path.Skip(1)).ToList();
        }

        private class StateInfo
        {
            public Point Start;
            public int Energy;
            public int Goal;

            public StateInfo(Point start, int energy, int goal)
            {
                Start = start;
                Energy = energy;
                Goal = goal;
            }

            public void ChangeValue(int goal, int energy, Point point)
            {
                Start = point;
                Energy -= energy;
                Goal -= goal;
            }
        }
    }
}