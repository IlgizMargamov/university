using System;
using NUnit.Framework;

namespace Manipulation
{
    public class TriangleTask
    {
        public static double GetABAngle(double a, double b, double c)
        {
            return ((a + b >= c) && (a + c >= b) && (b + c >= a))
                ? Math.Acos((a * a + b * b - c * c) / (2 * a * b))
                : double.NaN;
        }
    }

    [TestFixture]
    public class TriangleTask_Tests
    {
        [TestCase(3, 4, 5, Math.PI / 2)]
        [TestCase(1, 1, 1, Math.PI / 3)]
        [TestCase(5, 12, 13, Math.PI / 2)]
        [TestCase(1, 1, 5, double.NaN)]
        public void TestGetABAngle(double a, double b, double c, double expectedAngle)
        {
            var outcome = TriangleTask.GetABAngle(a, b, c);
            Assert.AreEqual(outcome, expectedAngle, 10e-10);
        }
    }
}