using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Xml;
using NUnit.Framework;

namespace Manipulation
{
    public static class ManipulatorTask
    {
        public static double[] MoveManipulatorTo(double x, double y, double alpha)
        {
            var wristX = x + Manipulator.Palm * Math.Cos(Math.PI - alpha);
            var wristY = y + Manipulator.Palm * Math.Sin(Math.PI - alpha);
            var zeroToWrist = Math.Sqrt(wristX * wristX + wristY * wristY);

            var elbow = TriangleTask.GetABAngle(Manipulator.UpperArm, Manipulator.Forearm, zeroToWrist);
            var shoulderToElbow = TriangleTask.GetABAngle(Manipulator.UpperArm, zeroToWrist, Manipulator.Forearm);

            var shoulderToOx = Math.Atan2(wristY, wristX);
            var shoulder = shoulderToOx + shoulderToElbow;

            var wrist = -alpha - shoulder - elbow;
            return new[] {shoulder, elbow, wrist};
        }
    }

    [TestFixture]
    public class ManipulatorTask_Tests
    {
        [Test]
        public void Tests()
        {
            for (var i = 0; i < 100; i++)
            {
                TestMoveManipulatorTo();
            }
        }

        public void TestMoveManipulatorTo()
        {
            var rnd = new Random();
            var x = rnd.Next(-1111, 1111);
            var y = rnd.Next(-1111, 1111);
            var alpha = rnd.NextDouble();

            var wristX = x + Manipulator.Palm * Math.Cos(Math.PI - alpha);
            var wristY = y + Manipulator.Palm * Math.Sin(Math.PI - alpha);

            var rmin = Math.Abs(Manipulator.UpperArm - Manipulator.Forearm);
            var rmax = Manipulator.UpperArm + Manipulator.Forearm;

            var answer = ManipulatorTask.MoveManipulatorTo(x, y, alpha);
            var joints = AnglesToCoordinatesTask.GetJointPositions(answer[0], answer[1], answer[2]);
            if (!double.IsNaN(answer[0]))
            {
                Assert.AreEqual(joints[2].X, x, 1e-5);
                Assert.AreEqual(joints[2].Y, y, 1e-5);
            }
            else
            {
                var center = new PointF(joints[2].X - joints[1].X, joints[2].Y - joints[1].Y);
                var centerCoord = (center.X + wristX) * (center.X + wristX) + (center.Y + wristY) * (center.Y + wristY);
                Assert.IsFalse(centerCoord - rmax * rmax > 1e-5, "outer circle");
                Assert.IsFalse(centerCoord - rmin * rmin < 1e-5, "inner circle");
            }
        }
    }
}