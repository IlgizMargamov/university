using System;
using System.Drawing;
using NUnit.Framework;

namespace Manipulation
{
    public static class AnglesToCoordinatesTask
    {
        public static PointF[] GetJointPositions(double shoulder, double elbow, double wrist)
        {
            var upperArmX = Manipulator.UpperArm * (float) Math.Cos(shoulder);
            var upperArmY = Manipulator.UpperArm * (float) Math.Sin(shoulder);

            var actualElbow = shoulder + Math.PI + elbow;
            var forearmX = upperArmX + Manipulator.Forearm * (float) Math.Cos(actualElbow);
            var forearmY = upperArmY + Manipulator.Forearm * (float) Math.Sin(actualElbow);

            var actualPalm = shoulder + elbow + wrist;
            var palmX = forearmX + Manipulator.Palm * (float) Math.Cos(actualPalm);
            var palmY = forearmY + Manipulator.Palm * (float) Math.Sin(actualPalm);

            var elbowPos = new PointF(upperArmX, upperArmY);
            var wristPos = new PointF(forearmX, forearmY);
            var palmEndPos = new PointF(palmX, (float) palmY);
            return new[]
            {
                elbowPos,
                wristPos,
                palmEndPos
            };
        }
    }

    [TestFixture]
    public class AnglesToCoordinatesTask_Tests
    {
        [TestCase(Math.PI / 2, Math.PI / 2, Math.PI, Manipulator.Forearm + Manipulator.Palm, Manipulator.UpperArm)]
        [TestCase(0, 0, 0, Manipulator.UpperArm - Manipulator.Palm, 0)]
        [TestCase(Math.PI / 2, Math.PI / 2, Math.PI / 2, Manipulator.Forearm,
            Manipulator.Forearm - Manipulator.Palm / 2)]
        [TestCase(0, -Math.PI / 2, Math.PI / 2, Manipulator.UpperArm + Manipulator.Palm, Manipulator.Forearm)]
        public void TestGetJointPositions(double shoulder, double elbow, double wrist, double palmEndX, double palmEndY)
        {
            var joints = AnglesToCoordinatesTask.GetJointPositions(shoulder, elbow, wrist);

            var joints0Y = joints[0].Y;
            var joints0X = joints[0].X;
            var joints1Y = joints[1].Y;
            var joints1X = joints[1].X;
            var joints2Y = joints[2].Y;
            var joints2X = joints[2].X;

            var dx0 = joints0X;
            var dy0 = joints0Y;
            var dx1 = joints1X - joints0X;
            var dy1 = joints1Y - joints0Y;
            var dx2 = joints2X - joints1X;
            var dy2 = joints2Y - joints1Y;

            Assert.AreEqual(Manipulator.UpperArm, Math.Sqrt(dx0 * dx0 + dy0 * dy0), 1e-5, "upper arm");
            Assert.AreEqual(Manipulator.Forearm, Math.Sqrt(dx1 * dx1 + dy1 * dy1), 1e-5, "forearm");
            Assert.AreEqual(Manipulator.Palm, Math.Sqrt(dx2 * dx2 + dy2 * dy2), 1e-5, "palm");

            Assert.AreEqual(palmEndX, joints[2].X, 1e-5, "palm endX");
            Assert.AreEqual(palmEndY, joints[2].Y, 1e-5, "palm endY");
        }
    }
}