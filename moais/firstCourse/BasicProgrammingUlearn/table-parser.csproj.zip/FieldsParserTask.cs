using System.Collections.Generic;
using NUnit.Framework;

namespace TableParser
{
    [TestFixture]
    public class FieldParserTaskTests
    {
        public static void Test(string input, string[] expectedResult)
        {
            var actualResult = FieldsParserTask.ParseLine(input);
            Assert.AreEqual(expectedResult.Length, actualResult.Count);
            for (var i = 0; i < expectedResult.Length; ++i)
            {
                Assert.AreEqual(expectedResult[i], actualResult[i].Value);
            }
        }

        [TestCase("", new string[0])]
        [TestCase("''", new[] {""})]
        [TestCase("\' ", new[] {" "})]
        [TestCase("text", new[] {"text"})]
        [TestCase(@""" \\""", new[] {" \\"})]
        [TestCase("hello world", new[] {"hello", "world"})]
        [TestCase(@"'\'text\''", new[] {@"'text'"})]
        [TestCase(@"'\'text\''", new[] {@"'text'"})]
        [TestCase(" hello  world ", new[] {"hello", "world"})]
        [TestCase(@"hello""world""", new[] {"hello", "world"})]
        [TestCase(@"""\""text\""""", new[] {@"""text"""})]
        [TestCase("hello world ' ' ", new[] {"hello", "world", " "})]
        [TestCase(@"""hello"" world", new[] {"hello", "world"})]
        [TestCase(@"""hello 'world hello' world""", new[] {"hello 'world hello' world"})]
        [TestCase(@"'hello ""world hello"" world'", new[] {@"hello ""world hello"" world"})]
        public static void RunTests(string input, string[] expectedOutput)
        {
            Test(input, expectedOutput);
        }
    }

    public class FieldsParserTask
    {
        public static List<Token> ParseLine(string line)
        {
            var newTokenLists = new List<Token>();
            var i = 0;
            var symbol = ' ';
            while (i < line.Length)
            {
                symbol = line[i];
                if (symbol == ' ')
                {
                    i++;
                    continue;
                }

                else if (TheFieldHasEnded(symbol))
                    SimpleFieldToAdd(line, i, newTokenLists);
                else
                    ComplexFieldToAdd(line, i, newTokenLists);

                i = newTokenLists[newTokenLists.Count - 1].GetIndexNextToToken();
            }

            return newTokenLists;
        }

        private static void ComplexFieldToAdd(string line, int i, List<Token> newTokenLists)
        {
            var fieldToAdd = ReadField(line, i);
            if (fieldToAdd.Length == 0)
                i++;
            newTokenLists.Add(fieldToAdd);
            i++;
        }

        private static void SimpleFieldToAdd(string line, int i, List<Token> newTokenLists)
        {
            var fieldToAdd = QuotedFieldTask.ReadQuotedField(line, i);
            if (fieldToAdd.Length == 0)
                i++;

            newTokenLists.Add(fieldToAdd);
            i++;
        }

        private static Token ReadField(string line, int startIndex)
        {
            var readField = "";
            var symbol = line[startIndex];
            for (var i = startIndex; i < line.Length; i++)
            {
                symbol = line[i];
                if (TheFieldHasEnded(symbol) || symbol == ' ')
                    break;
                readField += symbol;
            }

            return new Token(readField, startIndex, readField.Length);
        }

        public static Token ReadQuotedField(string line, int startIndex)
        {
            return QuotedFieldTask.ReadQuotedField(line, startIndex);
        }

        private static bool TheFieldHasEnded(char symbol)
        {
            return symbol == '\'' || symbol == '\"';
        }
    }
}