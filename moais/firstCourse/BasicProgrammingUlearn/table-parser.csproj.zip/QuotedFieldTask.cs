using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace TableParser
{
    [TestFixture]
    public class QuotedFieldTaskTests
    {
        [TestCase("''", 0, "", 2)]
        [TestCase("'a'", 0, "a", 3)]
        [TestCase("\"", 0, "", 1)]
        [TestCase("\"\"", 0, "", 2)]
        [TestCase("a\"b\"c", 1, "b", 3)]
        [TestCase("a \"c\"", 0, @" ""c""", 5)]
        [TestCase(@"""a\' b""", 0, "a' b", 7)]
        [TestCase(@"a b ""c""", 4, "c", 3)]
        [TestCase("'ab' 'cd'", 0, "ab", 4)]
        [TestCase("'ab' 'cd'", 5, "cd", 4)]
        public void Test(string line, int startIndex, string expectedValue, int expectedLength)
        {
            var actualToken = QuotedFieldTask.ReadQuotedField(line, startIndex);
            Assert.AreEqual(actualToken, new Token(expectedValue, startIndex, expectedLength));
        }
    }

    class QuotedFieldTask
    {
        public static Token ReadQuotedField(string line, int startIndex)
        {
            var lineLength = line.Length;
            var newLine = "";
            var i = startIndex + 1;
            var newLineLen = 1;

            while (i < lineLength && line[i] != line[startIndex])
            {
                if (line[i] == '\\')
                {
                    newLine += line[i + 1];
                    i++;
                }
                else
                    newLine += line[i];

                i++;
            }

            newLineLen = i - startIndex;
            if (i < lineLength && line[i] == line[startIndex])
                newLineLen++;
            return new Token(newLine, startIndex, newLineLen);
        }
    }
}