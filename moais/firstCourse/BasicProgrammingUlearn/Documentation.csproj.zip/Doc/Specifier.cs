using System.Linq;
using System.Reflection;

namespace Documentation
{
    public class Specifier<T> : ISpecifier
    {
        public string GetApiDescription()
        {
            return typeof(T)
                .GetCustomAttributes(false)
                .OfType<ApiDescriptionAttribute>()
                .FirstOrDefault()
                ?.Description;
        }

        public string[] GetApiMethodNames()
        {
            return typeof(T)
                .GetMethods()
                .Where(x => x
                    .GetCustomAttributes(false)
                    .OfType<ApiMethodAttribute>()
                    .FirstOrDefault() != null)
                .Select(methodInfo => methodInfo.Name)
                .ToArray();
        }

        public string GetApiMethodDescription(string methodName)
        {
            return typeof(T)
                .GetMethod(methodName)
                ?.GetCustomAttributes()
                .OfType<ApiDescriptionAttribute>()
                .FirstOrDefault()
                ?.Description;
        }

        public string[] GetApiMethodParamNames(string methodName)
        {
            return typeof(T)
                .GetMethod(methodName)
                ?.GetParameters()
                .Select(x => x.Name)
                .ToArray();
        }

        public string GetApiMethodParamDescription(string methodName, string paramName)
        {
            return typeof(T)
                .GetMethod(methodName)
                ?.GetParameters()
                .FirstOrDefault(x => x.Name == paramName)
                ?.GetCustomAttributes(false)
                .OfType<ApiDescriptionAttribute>()
                .FirstOrDefault()
                ?.Description;
        }

        public ApiParamDescription GetApiMethodParamFullDescription(string methodName, string paramName)
        {
            var methodInfo = typeof(T).GetMethod(methodName);
            var parameters = methodInfo
                ?.GetParameters()
                .FirstOrDefault(x => x.Name == paramName);
            var customAttributes = parameters
                ?.GetCustomAttributes();
            var requiredAttribute = customAttributes
                ?.OfType<ApiRequiredAttribute>()
                .FirstOrDefault();
            var validationAttribute = customAttributes
                ?.OfType<ApiIntValidationAttribute>()
                .FirstOrDefault();
            return new ApiParamDescription
            {
                MaxValue = validationAttribute?.MaxValue,
                MinValue = validationAttribute?.MinValue,
                Required = requiredAttribute != null && requiredAttribute.Required,
                ParamDescription = new CommonDescription(methodInfo == null ? "some" : paramName, customAttributes
                    ?.OfType<ApiDescriptionAttribute>()
                    .FirstOrDefault()
                    ?.Description),
            };
        }

        public ApiMethodDescription GetApiMethodFullDescription(string methodName)
        {
            var methodInfo = typeof(T).GetMethod(methodName);
            if (methodInfo
                ?.GetCustomAttributes()
                .OfType<ApiMethodAttribute>()
                .FirstOrDefault() == null) return null;
            var requiredAttribute = methodInfo
                .ReturnParameter
                ?.GetCustomAttributes()
                .OfType<ApiRequiredAttribute>()
                .FirstOrDefault();
            var validationAttribute = methodInfo
                .ReturnParameter
                ?.GetCustomAttributes()
                .OfType<ApiIntValidationAttribute>()
                .FirstOrDefault();
            return ApiMethodFullDescription(methodName, requiredAttribute, validationAttribute);
        }

        private ApiMethodDescription ApiMethodFullDescription(string methodName, ApiRequiredAttribute requiredAttribute,
            ApiIntValidationAttribute validationAttribute)
        {
            return new ApiMethodDescription
            {
                MethodDescription = new CommonDescription
                {
                    Name = methodName,
                    Description = GetApiMethodDescription(methodName)
                },
                ParamDescriptions = typeof(T)
                    .GetMethod(methodName)
                    ?.GetParameters()
                    .Select(x =>
                        GetApiMethodParamFullDescription(methodName, x.Name))
                    .ToArray(),
                ReturnDescription = requiredAttribute != null || validationAttribute != null
                    ? new ApiParamDescription
                    {
                        Required = requiredAttribute?.Required ?? false,
                        MaxValue = validationAttribute?.MaxValue,
                        MinValue = validationAttribute?.MinValue,
                    }
                    : null
            };
        }
    }
}