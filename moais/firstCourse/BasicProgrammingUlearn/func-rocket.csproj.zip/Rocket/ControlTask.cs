using System;

namespace func_rocket
{
    public class ControlTask
    {
        public static Turn ControlRocket(Rocket rocket, Vector target)
        {
            const double delta = 1;
            double angle;
            var toTarget = new Vector(target.X - rocket.Location.X, target.Y - rocket.Location.Y);
            if (Math.Abs(toTarget.Angle - rocket.Direction) < delta ||
                Math.Abs(toTarget.Angle - rocket.Velocity.Angle) < delta)
            {
                angle = (2 * toTarget.Angle - rocket.Direction - rocket.Velocity.Angle) / 2;
            }
            else
            {
                angle = toTarget.Angle - rocket.Direction;
            }

            if (angle > 0) return Turn.Right;
            else if (angle < 0) return Turn.Left;
            return Turn.None;
        }
    }
}