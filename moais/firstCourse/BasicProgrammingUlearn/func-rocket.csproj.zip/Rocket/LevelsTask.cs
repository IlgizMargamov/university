using System;
using System.Collections.Generic;

namespace func_rocket
{
    public class LevelsTask
    {
        static readonly Physics standardPhysics = new Physics();
        private static readonly Rocket rocket = new Rocket(new Vector(200, 500), Vector.Zero, -0.5 * Math.PI);
        private static readonly Vector target = new Vector(600, 200);

        public static IEnumerable<Level> CreateLevels()
        {
            yield return new Level("Zero", rocket, target, (size, location) => Vector.Zero, standardPhysics);
            yield return new Level("Heavy", rocket, target, (size, location) => new Vector(0, 0.9), standardPhysics);
            yield return new Level("Up", rocket, new Vector(700, 500),
                (size, location) => new Vector(0, -300 / (size.Height - location.Y + 300.0)), standardPhysics);
            yield return new Level("WhiteHole", rocket, target, (size, location) =>
            {
                var toWhole = new Vector(location.X - 600, location.Y - 200);
                return toWhole.Normalize() * 140 * toWhole.Length / (toWhole.Length * toWhole.Length + 1);
            }, standardPhysics);
            yield return new Level("BlackHole", rocket, target, (size, location) =>
            {
                var blackHole = new Vector((600 + 200) / 2, (500 + 200) / 2);
                var toBlackhole = blackHole - location;
                return new Vector(blackHole.X - location.X, blackHole.Y - location.Y).Normalize() * 300 *
                    toBlackhole.Length / (toBlackhole.Length * toBlackhole.Length + 1);
            }, standardPhysics);
            yield return new Level("BlackAndWhite", rocket, target,
                (size, location) => BlackAndWhiteWholeLength(location),
                standardPhysics);
        }

        private static Vector BlackAndWhiteWholeLength(Vector location)
        {
            var toWhole = new Vector(location.X - 600, location.Y - 200);
            var blackHole = new Vector((600 + 200) / 2, (500 + 200) / 2);
            var toBlackHole = blackHole - location;
            return (toWhole.Normalize() * 140 * toWhole.Length / (toWhole.Length * toWhole.Length + 1) +
                    new Vector(blackHole.X - location.X, blackHole.Y - location.Y).Normalize() * 300 *
                    toBlackHole.Length / (toBlackHole.Length * toBlackHole.Length + 1)) / 2;
        }
    }
}