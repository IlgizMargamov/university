﻿using System;
using System.Text;

namespace hashes
{
    public class GhostsTask :
        IFactory<Document>, IFactory<Vector>, IFactory<Segment>, IFactory<Cat>, IFactory<Robot>,
        IMagic
    {
        private readonly Vector vector = new Vector(0, 0);
        private readonly Segment segment = new Segment(new Vector(1, 1), new Vector(2, 2));
        private readonly Document document;
        private readonly byte[] content = {0, 1, 2, 3};
        private readonly Cat cat;
        private readonly Robot robot;

        public GhostsTask()
        {
            robot = new Robot("1", 12);
            cat = new Cat("Cat", "cat", DateTime.Today);
            document = new Document("doc", Encoding.UTF8, content);
        }

        public void DoMagic()
        {
            vector.Add(new Vector(1, 2));
            segment.End.Add(vector);
            content[0] = 1;
            cat.Rename("CAAAAT");
            Robot.BatteryCapacity++;
        }

        Vector IFactory<Vector>.Create()
        {
            return vector;
        }

        Segment IFactory<Segment>.Create()
        {
            return segment;
        }

        Document IFactory<Document>.Create()
        {
            return document;
        }

        Cat IFactory<Cat>.Create()
        {
            return cat;
        }

        Robot IFactory<Robot>.Create()
        {
            return robot;
        }
    }
}