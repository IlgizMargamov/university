using System;
using System.Collections.Generic;
using System.Linq;

namespace func.brainfuck
{
    public class BrainfuckBasicCommands
    {
        private static readonly char[] charArray = GenerateCharArray();

        public static void RegisterTo(IVirtualMachine vm, Func<int> read, Action<char> write)
        {
            int Abs(int pointer, int length) => (pointer + length - 1 % length) % length;
            vm.RegisterCommand('.', b => { write((char) vm.Memory[vm.MemoryPointer]); });
            vm.RegisterCommand('+', b => { unchecked { b.Memory[b.MemoryPointer]++; } });
            vm.RegisterCommand('-', b => { unchecked { b.Memory[b.MemoryPointer]--; } });
            vm.RegisterCommand(',', b => { vm.Memory[vm.MemoryPointer] = (byte) read(); });
            vm.RegisterCommand('>',
                b =>
                {
                    vm.MemoryPointer = (vm.MemoryPointer + vm.Memory.Length + 1 % vm.Memory.Length) % vm.Memory.Length;
                });
            vm.RegisterCommand('<',
                b => { vm.MemoryPointer = Abs(vm.MemoryPointer, vm.Memory.Length); });
            foreach (var c in charArray)
            {
                vm.RegisterCommand(c, b => { vm.Memory[vm.MemoryPointer] = (byte) c; });
            }
        }

        private static char[] GenerateCharArray()
        {
            return GenerateCharIEnumerables('0', '9').Concat(GenerateCharIEnumerables('A', 'Z'))
                .Concat(GenerateCharIEnumerables('a', 'z')).ToArray();
        }

        private static IEnumerable<char> GenerateCharIEnumerables(char start, char end)
        {
            for (var i = start; i <= end; i++)
                yield return i;
        }
    }
}