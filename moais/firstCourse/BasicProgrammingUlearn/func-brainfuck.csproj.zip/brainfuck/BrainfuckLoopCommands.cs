using System.Collections.Generic;

namespace func.brainfuck
{
    public class BrainfuckLoopCommands
    {
        private static readonly Stack<int> stack = new Stack<int>();

        public static void RegisterTo(IVirtualMachine vm)
        {
            var braces = new Dictionary<int, int>();
            Loop(vm, braces);
            vm.RegisterCommand('[', b =>
            {
                if (vm.Memory[vm.MemoryPointer] == 0) vm.InstructionPointer = braces[vm.InstructionPointer];
            });
            vm.RegisterCommand(']', b =>
            {
                if (vm.Memory[vm.MemoryPointer] != 0) vm.InstructionPointer = braces[vm.InstructionPointer];
            });
        }

        private static void Loop(IVirtualMachine vm, Dictionary<int, int> braces)
        {
            for (var i = 0; i < vm.Instructions.Length; i++)
            {
                switch (vm.Instructions[i])
                {
                    case '[':
                        stack.Push(i);
                        break;
                    case ']':
                        braces[stack.Peek()] = i;
                        braces[i] = stack.Pop();
                        break;
                }
            }
        }
    }
}