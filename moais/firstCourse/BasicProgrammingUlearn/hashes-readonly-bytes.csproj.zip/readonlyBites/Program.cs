﻿using System.Collections.Generic;
using System.Linq;
using NUnitLite;

namespace hashes
{
    class Program
    {
        public static void Main(string[] args)
        {
            new AutoRun().Execute(args);
        }
    }
}