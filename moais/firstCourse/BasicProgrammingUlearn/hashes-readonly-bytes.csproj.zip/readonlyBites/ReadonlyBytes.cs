﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace hashes
{
    public class ReadonlyBytes : IEnumerable<byte>
    {
        private readonly byte[] array;
        private readonly int hash;
        public int Length => array.Length;

        public ReadonlyBytes(params byte[] otherArray)
        {
            array = otherArray ?? throw new ArgumentNullException();
            hash = CountHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj != null && !(obj.GetType() == typeof(ReadonlyBytes)) || !(obj is ReadonlyBytes otherArray) ||
                array.Length != otherArray.Length) return false;
            var counter = array.Where((t, i) => t == otherArray[i]).Count();
            return counter == Length;
        }

        public override int GetHashCode() => hash;

        public override string ToString() => "[" + string.Join(", ", this) + "]";

        public byte this[int index]
        {
            get
            {
                if (index < 0 || index >= array.Length) throw new IndexOutOfRangeException();
                return array[index];
            }
        }

        public IEnumerator<byte> GetEnumerator()
        {
            if (array.Length <= 0) yield break;
            foreach (var b in array) yield return b;
        }

        private int CountHashCode()
        {
            const uint basis = 2166136261;
            const int prime = 16777619;
            int res;
            unchecked
            {
                res = array.Aggregate((int) basis, (current, b) => (current ^ b) * prime);
            }

            return res;
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}