﻿using System;

namespace Mazes
{
    public static class EmptyMazeTask
    {
        public static void MoveOut(Robot robot, int width, int height)
        {
            var wayToGoSide = width - 3;
            var wayToGoDown = height - 3;
            MoveRobotDown(robot, wayToGoDown);
            MoveRobotToRight(robot, wayToGoSide);
        }

        public static void MoveRobotToRight(Robot robot, int wayToGo)
        {
            for (int blocksToGo = 0; blocksToGo < wayToGo; blocksToGo++)
                robot.MoveTo(Direction.Right);
        }

        public static void MoveRobotDown(Robot robot, int wayToGo)
        {
            for (int blocksToGo = 0; blocksToGo < wayToGo; blocksToGo++)
                robot.MoveTo(Direction.Down);
        }
    }
}