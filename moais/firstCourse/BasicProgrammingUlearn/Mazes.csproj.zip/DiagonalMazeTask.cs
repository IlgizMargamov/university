﻿using System;

namespace Mazes
{
    public static class DiagonalMazeTask
    {
        public static void MoveOut(Robot robot, int width, int height)
        {
            var moveInHigher = (height - 3) / (width - 2);
            var moveInWider = (width - 3) / (height - 2);
            if (height > width)
                MoveInHighMaze(robot, moveInHigher);
            MoveInWiderMaze(robot, moveInWider);
        }

        private static void MoveInWiderMaze(Robot robot, int moveInWider)
        {

            for (int step = 0; step < moveInWider; step++)
                robot.MoveTo(Direction.Right);
            if (!robot.Finished)
            {
                robot.MoveTo(Direction.Down);
                MoveInWiderMaze(robot, moveInWider);
            }
        }
        private static void MoveInHighMaze(Robot robot, int moveInHigher)
        {
            for (int steps = 0; steps < moveInHigher; steps++)
                robot.MoveTo(Direction.Down);
            if (!robot.Finished)
            {
                robot.MoveTo(Direction.Right);
                MoveInHighMaze(robot, moveInHigher);
            }
        }
    }
}