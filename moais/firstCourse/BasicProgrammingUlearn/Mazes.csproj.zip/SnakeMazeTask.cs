﻿namespace Mazes
{
    public static class SnakeMazeTask
    {
        public static void MoveRobotToRight(Robot robot, int wayToGo)
        {
            for (int blocksToGo = 0; blocksToGo < wayToGo; blocksToGo++)
                robot.MoveTo(Direction.Right);
        }
        public static void MoveRobotToLeft(Robot robot, int wayToGo)
        {
            for (int blocksToGo = 0; blocksToGo < wayToGo; blocksToGo++)
                robot.MoveTo(Direction.Left);
        }
        public static void MoveRobotDown(Robot robot, int wayToGo)
        {
            for (int blocksToGo = 0; blocksToGo < wayToGo; blocksToGo++)
                robot.MoveTo(Direction.Down);
        }
        public static void MoveOut(Robot robot, int width, int height)
        {
            var wayToGoVertical = 2;
            var wayToGoSide = width - 3;

            MoveOneFloor(robot, wayToGoVertical, wayToGoSide);

            if (!robot.Finished)
            {
                MoveRobotDown(robot, wayToGoVertical);
                MoveOut(robot, width, height);
            }
        }

        private static void MoveOneFloor(Robot robot, int wayToGoVertical, int wayToGoSide)
        {
            MoveRobotToRight(robot, wayToGoSide);
            MoveRobotDown(robot, wayToGoVertical);
            MoveRobotToLeft(robot, wayToGoSide);
        }
    }
}