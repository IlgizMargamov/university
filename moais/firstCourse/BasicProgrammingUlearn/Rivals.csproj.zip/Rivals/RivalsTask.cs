﻿using System.Collections.Generic;
using System.Drawing;

namespace Rivals
{
    public class RivalsTask
    {
        public static IEnumerable<OwnedLocation> AssignOwners(Map map)
        {
            var playerQueue = new Queue<PlayerInfo>();
            var capturedPoints = new HashSet<Point>();
            FillInStartingPositions(map, capturedPoints, playerQueue);
            while (playerQueue.Count > 0)
            {
                var player = playerQueue.Dequeue();
                if (!map.InBounds(player.Position) ||
                    map.Maze[player.Position.X, player.Position.Y] == MapCell.Wall) continue;
                for (var dy = -1; dy <= 1; dy++)
                for (var dx = -1; dx <= 1; dx++)
                {
                    if (dx != 0 && dy != 0) continue;
                    var newPosition = new Point(player.Position.X + dx, player.Position.Y + dy);
                    if (capturedPoints.Contains(newPosition)) continue;
                    playerQueue.Enqueue(new PlayerInfo(newPosition,
                        player.Number, player.Turn + 1));
                    capturedPoints.Add(newPosition);
                }

                yield return new OwnedLocation(player.Number, player.Position, player.Turn);
            }
        }

        private static void FillInStartingPositions(Map map, HashSet<Point> capturedPoints,
            Queue<PlayerInfo> playerQueue)
        {
            for (var i = 0; i < map.Players.Length; i++)
            {
                var start = new Point(map.Players[i].X, map.Players[i].Y);
                capturedPoints.Add(start);
                playerQueue.Enqueue(new PlayerInfo(start, i, 0));
            }
        }
    }

    internal readonly struct PlayerInfo
    {
        public readonly Point Position;
        public readonly int Number;
        public readonly int Turn;

        public PlayerInfo(Point position, int number, int turn)
        {
            Position = position;
            Number = number;
            Turn = turn;
        }
    }
}