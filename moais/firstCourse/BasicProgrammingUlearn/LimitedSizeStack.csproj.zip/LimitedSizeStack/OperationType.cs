﻿namespace TodoApplication
{
    public enum OperationType
    {
        AddItem,
        RemoveItem
    }
}