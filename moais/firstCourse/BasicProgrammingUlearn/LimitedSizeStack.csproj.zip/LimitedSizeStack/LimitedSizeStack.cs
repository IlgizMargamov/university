﻿using System.Collections.Generic;

namespace TodoApplication
{
    public class LimitedSizeStack<T>
    {
        public int Count => linkedList.Count;

        private readonly LinkedList<T> linkedList = new LinkedList<T>();
        private readonly int limit;

        public LimitedSizeStack(int limit)
        {
            this.limit = limit;
        }

        /// <summary>
        /// Adds the item to the end of the list.
        /// </summary>
        /// <param name="item">Item to add</param>
        public void Push(T item)
        {
            linkedList.AddLast(item);
            if (linkedList.Count > limit) linkedList.RemoveFirst();
        }

        /// <summary>
        /// Gets the last added item to the list.
        /// </summary>
        /// <returns></returns>
        public T Pop()
        {
            var last = linkedList.Last.Value;
            linkedList.RemoveLast();
            return last;
        }
    }
}