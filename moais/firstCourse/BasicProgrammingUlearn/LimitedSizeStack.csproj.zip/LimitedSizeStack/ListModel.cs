﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TodoApplication
{
    public class ListModel<TItem>
    {
        public List<TItem> Items { get; }

        private int limit;
        private readonly LimitedSizeStack<Operation<TItem>> history;

        public ListModel(int limit)
        {
            Items = new List<TItem>();
            this.limit = limit;
            history = new LimitedSizeStack<Operation<TItem>>(limit);
        }

        public void AddItem(TItem item)
        {
            Items.Add(item);
            var actionToWrite = new Operation<TItem>(item, Items.IndexOf(item), OperationType.AddItem);
            history.Push(actionToWrite);
        }

        public void RemoveItem(int index)
        {
            var actionToWrite = new Operation<TItem>(Items.ElementAt(index), index, OperationType.RemoveItem);
            history.Push(actionToWrite);
            Items.RemoveAt(index);
        }

        public bool CanUndo()
        {
            return history.Count > 0;
        }

        public void Undo()
        {
            if (!CanUndo()) return;
            var task = history.Pop();
            switch (task.Action)
            {
                case OperationType.AddItem:
                    Items.RemoveAt(task.Index);
                    break;
                case OperationType.RemoveItem:
                    Items.Insert(task.Index, task.Item);
                    break;
            }
        }
    }
}