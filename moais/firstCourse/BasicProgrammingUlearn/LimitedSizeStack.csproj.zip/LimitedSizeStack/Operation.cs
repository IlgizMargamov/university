﻿using System;

namespace TodoApplication
{
    internal class Operation<TItem>
    {
        public readonly TItem Item;
        public readonly int Index;
        public readonly Enum Action;

        public Operation(TItem item, int index, Enum action)
        {
            Item = item;
            Index = index;
            Action = action;
        }
    }
}